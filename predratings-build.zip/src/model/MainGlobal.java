package model;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
/**
 * train a global model
 * @deprecated
 * */

public class MainGlobal {
	
	public static void main(String[] args) {
		MainGlobal generator = new MainGlobal();
		try {
			if(args[0].equals("first")){
				System.out.println("-- It is first time to run sampling --");
				generator.run(true);
			}else{
				generator.run(false);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void run(boolean isFirst) throws Exception{
		System.out.println("-- TrainCRFModel --");
		TrainGlobalModel gtrain = new TrainGlobalModel();
		gtrain.run(isFirst);
		
		/* serialization */
		try{
			ObjectOutputStream ModelOut=
				new ObjectOutputStream(
					new FileOutputStream("global_lamda_polarity.out"));
			ModelOut.writeObject(gtrain.lamda);
			ModelOut.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	
}
