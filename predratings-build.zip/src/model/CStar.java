package model;
/**
 * stars of comments
 * */
public enum CStar {
	ONE,TWO,THR,FOU,FIV
}
