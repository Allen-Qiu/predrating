package model;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 * read file termpairs4, they are term pairs.
 * TranCRFModel8 use this class
 * */
public class Dataset {
	ArrayList<Entry> rlist;
	int index;
	
	public static void main(String[] args){

	}
	public Dataset(){
		String line,stars,review;
		int rid;
		String[] str;
		rlist = new ArrayList<Entry>();
		RandomAccessFile raf;
		
		try {
			raf = new RandomAccessFile(GlobalVars.getInstance().trainFile,"r");
			while((line=raf.readLine())!=null){
				line=line.trim();
				if(line.isEmpty()) continue;
				str=line.split("\t");
				rid = Integer.parseInt(str[0]);
				review=str[1];
				stars=str[2];
				if(getStar(stars)==CStar.THR) continue;
				rlist.add(new Entry(rid,review,stars));
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	private CStar getStar(String star){
		int k;
		try{
			k = Integer.parseInt(star.trim());
			switch (k){
			case 1: return CStar.ONE;
			case 2:	return CStar.TWO;
			case 3:	return CStar.THR;
			case 4:	return CStar.FOU;
			case 5:	return CStar.FIV;
			}
		}catch(Exception e){
			return null;
		}
		return null;
	}

	public Comment next(){
		Comment comment=null;
		if(index>=rlist.size()){
			index=0;
			return null;
		}
		
		Entry entry=rlist.get(index);
		comment = new Comment(entry.rid, entry.stars,entry.review);
		index++;
		return comment;
	}
	public int size(){
		return rlist.size();
	}
}
