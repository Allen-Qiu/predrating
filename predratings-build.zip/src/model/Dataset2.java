package model;

import java.io.RandomAccessFile;
import java.util.ArrayList;

/**
 * prepare dataset for TrainMuModle where we excluse reviews with rating 3.
 * read dataset in a file "terms". it is terms (not term pairs) using for train status function
 * */
public class Dataset2 {
	ArrayList<Review> list;
	int index;
	boolean has3star;
	
	/**
	 * has3star, ���������ݼ�����3-star��������
	 * */
	public Dataset2(boolean has3star){
		this.has3star=has3star;
		list = new ArrayList<Review>();
		index = 0;
		try {
			System.out.println("-- read file "+GlobalVars.getInstance().trainMuFile+" --");
			readfile(GlobalVars.getInstance().trainMuFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public int size(){
		return list.size();
	}
	/**
	 * get next review
	 * */
	public Review next() throws Exception{
		if(index == list.size()) {
			index = 0;
			return null;
		}
//		System.out.println(index);
		return list.get(index++);
	}
	private void readfile(String filename) throws Exception{
		RandomAccessFile raf = new RandomAccessFile(filename,"r");
		String line;
		Review record;
		
		while((line=raf.readLine())!=null){
			line=line.trim();
			if(line.isEmpty()) return;
			record=getReview(line);
			if(!has3star&&record.cstar==CStar.THR) continue;
			list.add(record);
		}
	}
	private Review getReview(String lines){
		int rid;
		String[] str=lines.split("[\t| |,|	]");
		String[] s=new String[str.length-2];
		System.arraycopy(str, 1, s, 0, str.length-2);
		rid=Integer.parseInt(str[0]);
		Review record = new Review(rid,str[str.length-1],s);
		return record;
	}
	public static void main(String[] args) {

	}

}
