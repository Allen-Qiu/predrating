package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * ʹ��muģ�ͺ�terms.txt�ļ��������������ÿ�������ڴʵ��еı�ţ���������ʵ��
 * 
 * */
public class Exp2 {
	static ArrayList<Review> list;
	private final int POS=0, NEG=1;
	private final int[] POLARS={POS,NEG};
	ArrayList<Tuple> plist,nlist;
	HashMap<Integer,Integer> pmap, nmap;
	
	public static void main(String[] args) {
		System.out.println("-- expriment --");
		Exp2 exp = new Exp2();
		exp.run();
	}
	/**
	 * test polarity
	 * */
	private void run(){
		list = new ArrayList<Review>();
		MuModel muModel = new MuModel();
		Review review;
		CStar cs;
		int polar;
		int num1=0,num2=0,k1=0,k2=0, err=0;
		int rid;
		
		read();
		buildMap();
		try {
			readfile(GlobalVars.getInstance().trainMuFile);
			for(int i=0;i<list.size();i++){
				review = list.get(i);
				rid=review.getRid();
				if(review.getCStar()==CStar.THR)continue;
				polar = muModel.predict(review);
				
				if(polar==-1){
					err++;
					continue;
				}
				cs = review.getCStar();
				if(map(cs)==POS){
					if(map(cs)==polar){	// correct classification for pos tuple
						k1++;
						updateErrPTuple(rid,false);
					}else{
						updateErrPTuple(rid,true);
					}
					num1++;
				}else{
					if(map(cs)==polar){ // correct classfication for neg tuple
						k2++;
						updateErrNTuple(rid, false);
					}else{
						updateErrNTuple(rid, true);
					}
					num2++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		/* serialization */
		String ps="sampling/psampling.out";
		String ns="sampling/nsampling.out";
		
		try{
			ObjectOutputStream ModelOut=
				new ObjectOutputStream(
					new FileOutputStream(ps));
			ModelOut.writeObject(plist);
			ModelOut.close();
			
			ModelOut=new ObjectOutputStream(
					new FileOutputStream(ns));
			ModelOut.writeObject(nlist);
			ModelOut.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		System.out.println(num1+" "+k1+" "+k1*1.0/num1);
		System.out.println(num2+" "+k2+" "+k2*1.0/num2);
		System.out.println((num1+num2)+" "+(k1+k2)+" "+(k1+k2)*1.0/(num1+num2));
		System.out.println(err);
	}
	private int map(CStar cstar){
		if(cstar==CStar.FIV||cstar==CStar.FOU) return POS;
		if(cstar==CStar.ONE||cstar==CStar.TWO) return NEG;
		return -1;
	}

	private void readfile(String filename) throws Exception{
		RandomAccessFile raf = new RandomAccessFile(filename,"r");
		String line;
		Review record;
		
		while((line=raf.readLine())!=null){
			line=line.trim();
			if(line.isEmpty()) return;
			record=getReview(line);
			if(record.cstar==CStar.THR) continue;
			list.add(record);
		}
		raf.close();
	}
	private Review getReview(String lines){
		int rid;
		String[] str=lines.split("[ |,|	]");
		String[] s=new String[str.length-2];
		System.arraycopy(str, 1, s, 0, str.length-2);
		rid=Integer.parseInt(str[0]);
		Review record = new Review(rid, str[str.length-1],s);
		return record;
	}
	private void read(){
		File fp = new File("sampling/psampling.out");
		File fn = new File("sampling/nsampling.out");
		
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream(fp));
			plist = (ArrayList<Tuple>)ModelIn.readObject();
			ModelIn.close();
			ModelIn=
					new ObjectInputStream(
						new FileInputStream(fn));
				nlist = (ArrayList<Tuple>)ModelIn.readObject();
				ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void buildMap(){
		Tuple tuple;
		pmap=new HashMap<Integer,Integer>() ;
		nmap=new HashMap<Integer,Integer>() ;
		for(int i=0;i<plist.size();i++){
			tuple = plist.get(i);
			pmap.put(tuple.rid, i);
		}
		for(int i=0;i<nlist.size();i++){
			tuple = nlist.get(i);
			nmap.put(tuple.rid, i);
		}
	}
	/**
	 * update misclassification positive tuple
	 * */
	private void updateErrPTuple(int rid,boolean r){
		int index = pmap.get(rid);
		Tuple tuple = plist.get(index);
		tuple.isErr = r;
	}
	/**
	 * update misclassification negative tuple
	 * */
	private void updateErrNTuple(int rid, boolean r){
		int index = nmap.get(rid);
		Tuple tuple = nlist.get(index);
		tuple.isErr = r;
	}
}

