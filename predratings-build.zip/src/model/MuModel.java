package model;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.TreeMap;
import java.util.Vector;

import model.CStar;
import model.Element;
import model.Element2;
import model.Review;

/**
 * using mu (polarity) learned from SentiCRF to build predictive model
 * -- 2016.06 -- Qiu
 * */
public class MuModel {
	TreeMap<Integer, Element2> mu;
	final int POS=0, NEG=1;
	private final int[] POLARS={POS,NEG};

	public MuModel(){
		read();
	}
	public int predict(Review review){
		double[] polars = calcProb(review);
		double val,max=0;
		int r=-1;
		
		for(int i=0;i<POLARS.length;i++){
			val=polars[i];
			if(val>max) {
				r=i;
				max = val;
			}
		}
		return r;
	}
	private double[] calcProb(Review comment){
		int term;
		Element2 mele;
		double[] lSum = new double[POLARS.length];
		float sum=0;
		Vector<Integer> list = comment.getTerms();
		
		for(int i=0; i<list.size();i++){
			term = list.get(i);
			mele = mu.get(term);
//			if(mele==null){
////				System.out.println("rid:"+comment.getRid()+" term:"+term);
//				continue;
//			}
			sum=0;
			for(int j=0;j<POLARS.length;j++){
				sum+=mele.get(j);
			}
			for(int j=0;j<POLARS.length;j++){
				lSum[j]+=mele.get(j)/sum;
			}
			
		}
		sum=0;
		for(int i=0; i<lSum.length; i++){sum += lSum[i];}
		for(int i=0; i<lSum.length; i++){lSum[i] /= sum;}
		return lSum;
	}
	/**
	 * reading serialized global_mu.out to memory
	 * */
	private void read(){
		try{
			ObjectInputStream ModelIn=new ObjectInputStream(
					new FileInputStream("global_mu_polarity.out"));
			mu=(TreeMap<Integer, Element2>)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void main(String[] args){
		
	}
}
