package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 * TrainCRFModel6 uses this class. 
 * -- Qiu. 2015.10
 * */
public class SMatrix implements java.io.Serializable{
	private HashMap<Integer, Row> rows;
	int index;
	
	public SMatrix(){
		rows = new HashMap<Integer, Row>();
	}
	/**
	 * get one element
	 * */
	public Element get(int rindex, int cindex){
		Row row = rows.get(rindex);
		if(row == null) return null;
		return row.get(cindex);
	}
	/**
	 * use this function on building matrix
	 * rindex is index of row
	 * */
	public void put(int rindex, int cindex, Element ele){
		Row row = rows.get(rindex);
		if(row == null){
			row = new Row(rindex);
			row.put(cindex, ele);
			rows.put(rindex, row);
		}else{
			row.put(cindex, ele);
		}
		ele.index=index++;
	}
	/**
	 * 
	 * */
	public ArrayList<TermPair> getCollection(){
		ArrayList<TermPair> tlist=new ArrayList<TermPair>();
		
		Set<Integer> keyset = rows.keySet();
		Iterator<Integer> it = keyset.iterator();
		int rindex;
		Row row;
		Integer[] cols;
		
		while(it.hasNext()){
			rindex = it.next();
			row = rows.get(rindex);
			cols = row.getColIndexs();
			for(int i=0;i<cols.length;i++){
				tlist.add(new TermPair(row.rindex,cols[i]));
			}
		}
		return tlist;
	}
	class Row implements java.io.Serializable{
		private HashMap<Integer, Element> elist;	// list: one row of elements 
		int rindex;									// index of this row
		Row(int rindex){
			this.rindex = rindex;
			elist = new HashMap<Integer, Element>();
		}
		/**
		 * get one element
		 * */
		Element get(int cindex){
			return elist.get(cindex);
		}
		/**
		 * cindex: index of column
		 * ele: element of matrix
		 * */
		void put(int cindex, Element ele){
			Element old = elist.get(cindex);
			if(old == null){
				elist.put(cindex, ele);
			}else{
				throw new IllegalArgumentException("There has been a element in:"+rindex+","+cindex);
			}
		}
		Integer[] getColIndexs(){
			Set<Integer> keyset = elist.keySet();
			Integer[] r = new Integer[keyset.size()];
			keyset.toArray(r);
			return r;
		}
	}
}

