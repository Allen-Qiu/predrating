package model;
/**
 * This element is for polarity.
 * */
public class Element2 implements java.io.Serializable{
	float pos, neg;
	private final int POS=0, NEG=1;

	public Element2(){
		pos=0;neg=0;
	}
	public void inc(int polarity) {
		switch (polarity){
			case POS: pos += 1; break;
			case NEG: neg += 1; break;
			default: 
				throw new IllegalArgumentException("order is out of bound");
		}
		
	}
	public float get(int polarity){
		switch (polarity){
			case NEG: return neg;
			case POS: return pos;
			default: 
				throw new IllegalArgumentException("order is out of bound");
		}
	}
	public void set(int polarity, float val){
		switch(polarity){
		case NEG: neg=val;break;
		case POS: pos=val;break;
		default:
			throw new IllegalArgumentException("order is out of bound");
		}
	}
}
