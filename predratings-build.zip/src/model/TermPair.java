package model;
public class TermPair{
	public int coreIndex, contextIndex;	// index of core word and contextIndex 
	
	public TermPair(int coreIndex, int contextIndex){
		this.contextIndex = contextIndex;
		this.coreIndex = coreIndex;
	}
}