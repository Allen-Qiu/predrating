package analysis;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import dataset.SynTerm;
import model.GlobalVars;

/**
 * �����ʵ�
 * */
public class Ana3 {

	public static void main(String[] args) {
		HashMap<String, SynTerm> dic = null;
		HashMap<Integer, SynTerm> inverseDic;
		
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream(GlobalVars.getInstance().dicName));
			dic = (HashMap<String, SynTerm>)ModelIn.readObject();
			ModelIn.close();
			
			ModelIn=new ObjectInputStream(
						new FileInputStream(GlobalVars.getInstance().invDicName));
			inverseDic = (HashMap<Integer, SynTerm>)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		Collection<SynTerm> coll = dic.values();
		System.out.println(coll.size());
		Iterator<SynTerm> it = coll.iterator();
		SynTerm syn;
		
		while(it.hasNext()){
			syn = it.next();
//			System.out.println(syn.index+" "+syn.term);
		}
	}

}
