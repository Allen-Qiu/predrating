package qjt.predratings;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.RandomAccessFile;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;
import java.util.Vector;

import dataset.MyRules;
import dataset.MyVector;
import dataset.SynTerm;
import model.Comment;
import model.Element;
import model.Element2;
import model.GlobalVars;
import model.SMatrix;
import model.TermPair;
import qjt.termextract.Extractor;
import qjt.termextract.Extractor4E;
import qjt.termextract.TermTag;

/**
 * It is a interface for predicting ratings.
 * giving a review, it will return a rating.
 * give a file, where each line is a review, it will return a list of percentage of ratings.
 * -- 2016.08 --
 * */
public class RMain {
	Extractor ext;
	HashMap<String, SynTerm> dic;
	SMatrix lamda;
	TreeMap<Integer, Element2> mu;
	CLM clm;
	double[] s;
	private final int POS=0, NEG=1;
	
	public RMain(Extractor ext, CLM clm){
		this.ext = ext;
		this.clm = clm;
		System.out.println("--- reading objects ---");
		read();
	}
	/**
	 *  give a file, where each line is a review, 
	 *  it will return a list of percentage of ratings.
	 * */
	public double[] run2(String fname){
		RandomAccessFile rin;
		int stars;
		String review;
		int sum=0;
		int[] ratings=new int[5];
		double[] percent=new double[5]; 
				
		try{
			rin=new RandomAccessFile(fname,"r");
			while((review=rin.readLine())!=null){
				review=review.trim();
				if(review.isEmpty()) continue;
				stars=run(review);
				ratings[stars-1]++;
				sum++;
			}
			
			for(int i=0;i<percent.length;i++){
				percent[i]=ratings[i]*1.0/sum;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return percent;
		
	}
	/**
	 * give a review, return its rating 1-5
	 * */
	public int run(String review){
		int ratings=3;
		String[] str = review.split(MyRules.subRule);
		String r, sentence="";
		MyVector vec=new MyVector();
		int[] na;
		s=new double[2];
		Vector<Integer> terms=new Vector<Integer>();
		
		try{
			for(int i=0;i<str.length;i++){
				r = process(str[i], terms);
				if(r == null||r.isEmpty()) continue;
				sentence += r+";";
			}
			na=processOneReview(sentence);
			vec.nap=na[0];
			vec.nan=na[1];
			vec.sp=s[0];
			vec.sn=s[1];
			build2(vec, terms);
			ratings=clm.run(vec);
		}catch(Exception e){
			e.printStackTrace();
		}
		return ratings;
	}
	/**
	 * ��һ������ת����term-pairs���б�
	 * */
	private String process(String line, Vector<Integer> terms) throws Exception{
		Vector<Integer> termList = new Vector<Integer>();
		Integer[] list;
		Vector<TermTag> vec=ext.extract(line);
		String token;
		String sToken;
		TermTag ttag;
		SynTerm syn;
		
		for(int i=0;i<vec.size();i++){
			ttag = vec.get(i);
			token = ttag.term;
			sToken=ext.stem(token);
			syn=dic.get(sToken);
			if(syn!=null){	
				termList.add(syn.index);
				terms.add(syn.index);
			}
		}
		
		list = new Integer[termList.size()];
		termList.toArray(list);
		return buildSentence(list);
	}
	private String buildSentence(Integer[] termList){
		int row, col;
		String result="";
		
		for(int i=0;i<termList.length-1;i++){
			row = termList[i];
			for(int j=i+1;j<termList.length;j++){
				col = termList[j];
				if(row == col) continue;
				result +="{"+row+","+col+"}";
			}
		}
		return result;
	}
	
	 /**
	  *  ����һ������
	 * */
	private int[] processOneReview(String review){
		String str[]=review.split(";");
		Comment comment;
		int sa;
		int nap=0, nan=0;
		
		for(int i=0;i<str.length;i++){
			comment = new Comment(0, null, str[i]);
			sa=calcSA(comment);
			if(sa>0) nap++;
			else nan++;
		}
		return new int[]{nap,nan};
	}
	/**
	 * ����һ�����ӵ�SA
	 * */
	private int calcSA(Comment comment){
		List<TermPair> tlist=comment.getTPair();
		TermPair tp;
		double ap=0, an=0;
		Element ele;
		
		for(int i=0;i<tlist.size();i++){
			tp=tlist.get(i);
			ele=lamda.get(tp.coreIndex, tp.contextIndex);
			if(ele==null){
				ele=lamda.get(tp.contextIndex, tp.coreIndex);
			}
			if(ele==null){
				continue;	// һЩtermpair������������3-stars������
			}
			s[0]+=(ele.pos+1)/(ele.pos+ele.neg+2);
			s[1]+=(ele.neg+1)/(ele.pos+ele.neg+2);
			ap+=Math.log(ele.pos+1);
			an+=Math.log(ele.neg+1);
		}
		
		if(ap>an){
			return 1;
		}else{
			return -1;
		}
	}
	/**
	 * ����terms�ļ�, ��������t_p, t_n, len
	 * */
	private void build2(MyVector vec, Vector<Integer> terms) throws Exception{
		Integer term;
		Element2 ele;
		double mup, mun;
		
		mup=0; mun=0;
		
		for(int i=0;i<terms.size();i++){
			term = terms.get(i);
			ele=mu.get(term);
			if(ele==null){
				continue; 	// һЩterm������������3-stars reviews��
			}
			mup+=(ele.get(POS)+1)/(ele.get(POS)+ele.get(NEG)+2);
			mun+=(ele.get(NEG)+1)/(ele.get(POS)+ele.get(NEG)+2);
		}
		vec.tp=mup;
		vec.tn=mun;
		vec.len=terms.size();
	}
	private void read(){
		ObjectInputStream ModelIn;
		
		try{
			ModelIn=new ObjectInputStream(
					new FileInputStream(PathVar.path+"global_lamda_polarity.out"));
			lamda=(SMatrix)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		try{
			ModelIn=new ObjectInputStream(
					new FileInputStream(PathVar.path+"global_mu_polarity.out"));
			mu=(TreeMap<Integer, Element2>)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		try{
			ModelIn=new ObjectInputStream(
					new FileInputStream(PathVar.path+"dic/cdic.out"));
			dic=(HashMap<String, SynTerm>)ModelIn.readObject();
			System.out.println(GlobalVars.getInstance().dicName);
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
