package qjt.termextract;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.ling.TaggedWord;
import edu.stanford.nlp.ling.Word;
import edu.stanford.nlp.process.Morphology;
import edu.stanford.nlp.tagger.maxent.MaxentTagger;
import qjt.predratings.PathVar;

public class Postagger {
	 MaxentTagger tagger;
	 Morphology m;
	public Postagger(){
		tagger = new MaxentTagger(PathVar.path+"stanford/models/english-bidirectional-distsim.tagger");
		 m = new Morphology();
	}
	public List<List<TaggedWord>> run(String line) throws Exception{
	    List<List<HasWord>> sentences = MaxentTagger.tokenizeText(new StringReader(line));
	    List<List<TaggedWord>> list=new ArrayList<List<TaggedWord>>();
	    
	    for (List<HasWord> sentence : sentences) {
	    	List<TaggedWord> tSentence = tagger.tagSentence(sentence);
	    	list.add(tSentence);
	    }
	    return list;
	}
	/**
	 * �õ�һ������stem
	 * */
	public String stem(String token){
		return m.stem(token);
	}
	/**
	 * ���һ���ʵĴ���
	 * */
	public String getTag(String token){
		String tag=tagger.tagString(token);
		String[] str=tag.split("_");
		tag=str[1];
		return tag;
	}
	public static void main(String[] args){
		Postagger p = new Postagger();
		String line="I might give him a  advice";
		List<List<TaggedWord>> list;
		
		try {
			list = p.run(line);
			for(List<TaggedWord> sentence : list){
				System.out.println("--------------------------");
				for(TaggedWord word :sentence){
					System.out.println(p.stem(word.word())+"-"+word.tag());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
