package qjt.termextract;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Vector;

/**
 * �ж��ǲ���һ��phrase
 * */
class PhraseTree implements java.io.Serializable{
	HashSet<String> sset;	// ����ǰ׺��set
	HashSet<String> pset;	// ����phrase��set
	
	/**
	 * ������һ��phrase����
	 * */ 
	PhraseTree(String[] phrases){
		sset=new HashSet<String>();
		pset=new HashSet<String>();
		add(phrases);
	}
	PhraseTree(Vector<String> vec){
		String[] str=new String[vec.size()];
		for(int i=0;i<str.length;i++){
			str[i]=vec.get(i);
		}
		sset=new HashSet<String>();
		pset=new HashSet<String>();
		add(str);
	}
	private void add(String[] phrases){
		String ph;
		String[] tokens;
		String token;
		String str;
		
		for(int i=0;i<phrases.length;i++){
			ph=phrases[i];
			pset.add(ph);
			tokens=ph.split("-");
			str="";
			
			for(int j=0;j<tokens.length-1;j++){
				token=tokens[j];
				str+=token+"-";
				sset.add(str.substring(0,str.length()-1));
			}
		}
	}
	/**
	 * find first(head) of a phrase
	 * */
	boolean findPrefix(String term){
		if(sset.contains(term)) return true;
		return false;
	}
	boolean find(String term){
		if(pset.contains(term)) return true;
		return false;
	}
	void print(){
		Iterator<String> it=sset.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		System.out.println("----------------");
		it=pset.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
	}
	public static void main(String[] args) {
		String[] str={"A-B-D","A-C","B-C","B-C-D-E-F","B-C-D","A-C-D","B-D","B-E"};
		PhraseTree pt=new PhraseTree(str);
		pt.print();
	}
}
