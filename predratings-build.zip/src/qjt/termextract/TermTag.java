package qjt.termextract;

public class TermTag {
	public String term;
	public String tag;
	
	public TermTag(String term, String tag){
		this.term=term;
		this.tag=tag;
	}
}	
