package dataset;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.ling.TaggedWord;
import edu.stanford.nlp.ling.Word;
import edu.stanford.nlp.process.Morphology;
import edu.stanford.nlp.tagger.maxent.MaxentTagger;

public class Postagger {
	 MaxentTagger tagger;
	public Postagger(){
		tagger = new MaxentTagger("tagmodel/english-bidirectional-distsim.tagger");
	}
	public List<List<TaggedWord>> run(String line) throws Exception{
	    List<List<HasWord>> sentences = MaxentTagger.tokenizeText(new StringReader(line));
	    List<List<TaggedWord>> list=new ArrayList<List<TaggedWord>>();
	    
	    for (List<HasWord> sentence : sentences) {
	    	List<TaggedWord> tSentence = tagger.tagSentence(sentence);
	    	list.add(tSentence);
	    }
	    return list;
	}
	/**
	 * Ϊһ���ʻ�����Ĵ���
	 * */
	public String getPOS(String term){
		return tagger.tagString(term);
	}
	public static void main(String[] args){
		Postagger p = new Postagger();
		String line="I might give him a  advice";
		List<List<TaggedWord>> list;
		Morphology m = new Morphology();
		
		try {
			list = p.run(line);
			for(List<TaggedWord> sentence : list){
				System.out.println("--------------------------");
				for(TaggedWord word :sentence){
					System.out.println(m.stem(word.word())+"-"+word.tag());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
