package dataset;

/**
 * һ������
 * */
public class MyVector {
	public double nap;
	public double nan;
	public double sp;
	public double sn;
	public double tp;
	public double tn;
	public int len;
	public int rid;
	public String stars;
	
}
