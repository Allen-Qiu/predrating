package dataset;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.GlobalVars;

/**
 * ����Ƶ������ѡtermpairs��Ȼ��Դʵ����Լ��,ɾ���ʵ��е�һЩ��Ƶ�ʡ���������ʵ䡣
 * �γ�termpairs.txt��terms.txt�����ļ���ѵ��ģ��ʹ�á�
 * 
 * -- 2017.09 -- J. Qiu
 * */
public class Selector {
	HashMap<String, Integer> tpMap;
	int th = 5;			// ɾ����ƵС��th��termpairs
	HashMap<String, SynTerm> dic;
	HashMap<Integer, SynTerm> inverseDic;
	HashSet<String> tset;
	
	public void run(){
		tpMap = new HashMap<String, Integer>();
		tset = new HashSet<String>();
		inverseDic = new HashMap<Integer, SynTerm> ();
		
		try {
			getRecord();
			System.out.println(tpMap.size());
			delete(th);
			System.out.println(tpMap.size());
			updateDic();
			buildInverseDic();
			serialize();
			buildFiles();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void getRecord() throws Exception{
		OperateDB opdb=OperateDB.getInstance();
		opdb.connect(GlobalVars.getInstance().dbName);
		String command="select rid, stars, comment from termpairs order by rid";
		ResultSet rs;
		String comment;
		
		rs = opdb.select(command);
		while(rs.next()){
			comment=rs.getString("comment");
			put(comment);
		}
		opdb.disconnect();
	}
	
	private void put(String review){
		String core, context;
		
		String regex="\\{(\\d+?),(\\d+?)\\}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(review);
		String key1, key2;
		Integer count;
		
		while(m.find()){
			core = m.group(1);
			context = m.group(2);
			key1="{"+core+","+context+"}";
			key2="{"+context+","+core+"}";
			if(tpMap.containsKey(key1)){
				count=tpMap.get(key1);
				count++;
				tpMap.put(key1, count);
			}else if(tpMap.containsKey(key2)){
				count=tpMap.get(key2);
				count++;
				tpMap.put(key2, count);
			}else{
				tpMap.put(key1, 1);
			}
		}
	}
	/**
	 * ɾ��tpMap�д�Ƶ����th��termpairs
	 * */
	private void delete(int th){
		HashMap<String, Integer> tpMap2 = (HashMap<String, Integer>)tpMap.clone();
		Set<Entry<String, Integer>> set = tpMap2.entrySet();
		Entry<String, Integer> entry;
		Iterator<Entry<String, Integer>> it = set.iterator();
		int val;
		String key;
		
		String regex="\\{(\\d+?),(\\d+?)\\}";
		Pattern p = Pattern.compile(regex);
		Matcher m;
		String core, context;
		
		while(it.hasNext()){
			entry = it.next();
			val = entry.getValue();
			key = entry.getKey();
			m = p.matcher(key);
			
			while(m.find()){
				core = m.group(1);
				context = m.group(2);
				if(val<th){
					tpMap.remove(key);
				}else{
					tset.add(context);
					tset.add(core);
				}
			}
		}
	}
	/**
	 * using tpMap update dictionary
	 * */
	private void updateDic() throws Exception{
		Set<Entry<String, SynTerm>>  set;
		Entry<String, SynTerm> entry;
		HashMap<String, SynTerm> dic2;
		String key;
		SynTerm syn;
		System.out.println("size:"+tset.size());
		
		ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream(GlobalVars.getInstance().dicName));
		dic = (HashMap<String, SynTerm>)ModelIn.readObject();
		ModelIn.close();
		dic2 = (HashMap<String, SynTerm>)dic.clone(); 
		set = dic2.entrySet();
		Iterator<Entry<String, SynTerm>> it = set.iterator();
		
		while(it.hasNext()){
			entry = it.next();
			key = entry.getKey();
			syn = entry.getValue();
			
			if(!tset.contains(syn.index+"")){
				dic.remove(key);
			}
		}
		System.out.println("dic size:"+dic.size());
	}
	/**
	 * ��������ʵ䣨�ӱ�ŵ�SysTerm��ӳ�䣩
	 * */
	private void buildInverseDic(){
		Set<Entry<String, SynTerm>>  set=dic.entrySet();
		Entry<String, SynTerm> entry;
		Iterator<Entry<String, SynTerm>>  it=set.iterator();
		SynTerm syn;
		
		while(it.hasNext()){
			entry=it.next();
			syn=entry.getValue();
			inverseDic.put(syn.index,syn);
		}
	}
	/**
	 * ���ʵ�dic���л����
	 * */
	private void serialize() throws Exception{
		ObjectOutputStream ModelOut=
				new ObjectOutputStream(
						new FileOutputStream(GlobalVars.getInstance().dicName));

		ModelOut.writeObject(dic);
		ModelOut.close();
			
		ModelOut=new ObjectOutputStream(
					new FileOutputStream(GlobalVars.getInstance().invDicName));
		ModelOut.writeObject(inverseDic);;
		ModelOut.close();
	}
	/**
	 * ����termpairs��terms�����ļ�
	 * */
	private void buildFiles() throws Exception{
		OperateDB opdb=OperateDB.getInstance();
		opdb.connect(GlobalVars.getInstance().dbName);
		String command="select rid, stars, comment from termpairs order by rid";
		ResultSet rs;
		String rid, stars, comment;
		PrintWriter pw1 = new PrintWriter(new BufferedWriter(new FileWriter("termpairs.txt")));
		PrintWriter pw2 = new PrintWriter(new BufferedWriter(new FileWriter("terms.txt")));
		String[] lines;
		
		rs = opdb.select(command);
		while(rs.next()){
			rid = rs.getString("rid");
			stars = rs.getString("stars");
			comment = rs.getString("comment");
			lines = buildOneLine(rid, stars, comment);
			pw1.println(lines[0]);
			pw2.println(lines[1]);
		}
		pw1.close();
		pw2.close();
	}
	/**
	 * Ϊtermpairs�ļ�����һ��
	 * */
	private String[] buildOneLine(String rid, String stars, String comment){
		
		String regex="\\{(\\d+?),(\\d+?)\\}";
		Pattern p = Pattern.compile(regex);
		Matcher m;
		String core, context;
		String[] lines = new String[2];
		lines[0] = ""; lines[1] = "";
		m = p.matcher(comment);
		String tp1, tp2;
		HashSet<String> hset = new HashSet<String>();
		
		while(m.find()){
			core = m.group(1);
			context = m.group(2);
			tp1="{"+core+","+context+"}";
			tp2="{"+context+","+core+"}";
			
			if(tpMap.containsKey(tp1)){
				lines[0] += tp1+","; 
				hset.add(core);
				hset.add(context);
			}else if(tpMap.containsKey(tp2)){
				lines[0] += tp2+",";
				hset.add(core);
				hset.add(context);
			}
		}
		
		String line="";
		Iterator<String> it = hset.iterator();
		while(it.hasNext()){
			line += it.next()+",";
		}
		lines[1] = rid+"\t"+line+"\t"+stars;
		lines[0] = rid+"\t"+lines[0]+"\t"+stars;
		return lines;
	}
	public static void main(String[] args) {
		Selector selector = new Selector();
		selector.run();
	}
}
