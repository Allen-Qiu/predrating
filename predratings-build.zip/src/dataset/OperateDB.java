package dataset;

import java.sql.*;

/**
 * connect to Database
 * ����Singletonģʽ
 * 
 * @author Qiu
 * @since 2010.04.11
 * */
public class OperateDB {
	private Connection connection;
	
	private static final OperateDB Instance=new OperateDB();
	
	private OperateDB(){
		connection=null;
	}
	public static OperateDB getInstance(){
		return Instance;
	}
	/**
	 * sql server
	 * */
	public void connect(String DBName){
		String username;
		String password;
		try {
	    	 
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
	     }
	     catch (Exception e) {
	         System.out.println(
	         "Unable to register the JDBC Driver for sql server 2005.\n" +
	         "Make sure the JDBC driver is in the\n" +
	         "classpath.\n");
	         System.exit(1);
	     }

	     String url="jdbc:sqlserver://127.0.0.1:1433;DatabaseName="+DBName;
	     username = "sa";
	     password = "123456";
	     try {
	         connection = DriverManager.getConnection(url, username, password);
//	         System.out.println("open!");
	     }
	     catch (SQLException e) {
	         System.out.println(
	         "Unable to make a connection to the database.\n" +
	         "The reason: " + e.getMessage());
	         System.exit(1);
	         return;
	     }
	    
	}
	/**
	 * disconnect from db
	 * */
	public void disconnect(){
		 try{
		     if (connection!=null)
			    connection.close();
		 }
		 catch(SQLException e){}
	 }
	/**
	 * ���롢���¡�ɾ����������
	 * */
	public boolean operate(String command) throws Exception{
		Statement statement=connection.createStatement();
		statement.executeUpdate(command);
		return true;
    }
	/**
	 * return query result
	 * */
	public ResultSet select(String command)throws Exception{
		Statement statement=connection.createStatement();
		ResultSet rs=statement.executeQuery(command);
		return rs;
	}
}