package dataset;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.RandomAccessFile;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

import model.SMatrix;

public class Test {
	
	public static void main(String[] args){
		try{
			RandomAccessFile raf = new RandomAccessFile("terms.txt","r");
			int k = 0;
			String line;
			
			while(true){
				line = raf.readLine();
				if(line==null) break;
				k++;
			}
			System.out.println(k);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}







