package dataset;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.RandomAccessFile;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

import model.CStar;
import model.Comment;
import model.Dataset;
import model.Dataset2;
import model.Element;
import model.Element2;
import model.Review;
import model.SMatrix;
import model.TermPair;

/**
 * ��reviewsת���ɣ�cumulative logit model��Ҫ������
 * */
public class GenerateVector {
	SMatrix lamda;
	TreeMap<Integer, Element2> mu;
	TreeMap<Integer, MyVector> vmap;
	String tpfile="termpairs.txt";
	String outfile="vector.txt";
	double[] s;
	private final int POS=0, NEG=1;
	
	public static void main(String[] args) {
		GenerateVector gvec=new GenerateVector();
		File f=new File(gvec.outfile);
		
		if(f.exists()){
			f.delete();
		}
		
		try {
			gvec.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void run() throws Exception{
		vmap=new TreeMap<Integer, MyVector>();
		read();
		System.out.println("---- read object ----");
		build1();
		System.out.println("---- built first part ----");
		build2();
		System.out.println("---- built second part ----");
		write2file();
		System.out.println("---- end ----");
	}
	/**
	 * ����termpairs�ļ�����������n_ap��n_an��s_p, s_n
	 * */
	private void build1() throws Exception{
		RandomAccessFile raf=new RandomAccessFile(tpfile,"r");
		String line;
		String[] str;
		int rid;
		String star;
		String review;
		MyVector vec;
		int[] na;
		
		while((line=raf.readLine())!=null){		// һ������
			s=new double[2];
			str=line.split("\t");
			rid = Integer.parseInt(str[0]);
			review=str[1];
			star=str[2];
			vec=new MyVector();
			vec.rid=rid;
			vec.stars=star;
			na=processOneReview(review);
			vec.nap=na[0];
			vec.nan=na[1];
			vec.sp=s[0];
			vec.sn=s[1];
			vmap.put(rid, vec);
		}
		raf.close();
	}
	/**
	 * ����һ������
	 * */
	private int[] processOneReview(String review){
		String str[]=review.split(";");
		Comment comment;
		int sa;
		int nap=0, nan=0;
		for(int i=0;i<str.length;i++){
			comment = new Comment(0, null, str[i]);
			sa=calcSA(comment);
			if(sa>0) nap++;
			else nan++;
		}
		return new int[]{nap,nan};
	}
	/**
	 * ����һ�����ӵ�SA
	 * */
	private int calcSA(Comment comment){
		List<TermPair> tlist=comment.getTPair();
		TermPair tp;
		double ap=0, an=0;
		Element ele;
		
		for(int i=0;i<tlist.size();i++){
			tp=tlist.get(i);
			ele=lamda.get(tp.coreIndex, tp.contextIndex);
			if(ele==null){
				ele=lamda.get(tp.contextIndex, tp.coreIndex);
			}
			if(ele==null){
				continue;	// һЩtermpair������������3-stars������
			}
			s[0]+=(ele.pos+1)/(ele.pos+ele.neg+2);
			s[1]+=(ele.neg+1)/(ele.pos+ele.neg+2);
			ap+=Math.log(ele.pos+1);
			an+=Math.log(ele.neg+1);
		}
		
		if(ap>an){
			return 1;
		}else{
			return -1;
		}
	}
	/**
	 * ����terms�ļ�, ��������t_p, t_n, len
	 * */
	private void build2() throws Exception{
		Dataset2 dataset = new Dataset2(true);
		Review comment;
		Vector<Integer> terms;
		Integer term;
		int rid;
		MyVector vec;
		Element2 ele;
		double mup, mun;
		
		while((comment = dataset.next())!=null){
			rid=comment.getRid();
			terms = comment.getTerms();
			mup=0; mun=0;
			
			for(int i=0;i<terms.size();i++){
				term = terms.get(i);
				ele=mu.get(term);
				if(ele==null){
					continue; 	// һЩterm������������3-stars reviews��
				}
				mup+=(ele.get(POS)+1)/(ele.get(POS)+ele.get(NEG)+2);
				mun+=(ele.get(NEG)+1)/(ele.get(POS)+ele.get(NEG)+2);
			}
			vec=vmap.get(rid);
			vec.tp=mup;
			vec.tn=mun;
			vec.len=terms.size();
		}
	}
	/**
	 * ������������д���ļ�
	 * */
	private void write2file() throws Exception{
		RandomAccessFile raf=new RandomAccessFile(outfile,"rw");
		Integer rid;
		Set<Integer> vset=vmap.keySet();
		Iterator<Integer> it=vset.iterator();
		String line;
		MyVector vec;
		
		while(it.hasNext()){
			rid=it.next();
			vec=vmap.get(rid);
			line=vec.rid+","+vec.nap+","+vec.nan+","+vec.sp+","+vec.sn+","+
					vec.tp+","+vec.tn+","+vec.len+","+vec.stars;
			raf.writeBytes(line+"\n");
		}
		raf.close();
	}
	/**
	 * ����termpairs�ļ�������ת����termpairs��reviews
	 * ����ʵ�
	 * */
	private void read(){
		ObjectInputStream ModelIn;
		
		try{
			ModelIn=new ObjectInputStream(
					new FileInputStream("global_lamda_polarity.out"));
			lamda=(SMatrix)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		try{
			ModelIn=new ObjectInputStream(
					new FileInputStream("global_mu_polarity.out"));
			mu=(TreeMap<Integer, Element2>)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
