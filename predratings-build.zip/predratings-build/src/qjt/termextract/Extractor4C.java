package qjt.termextract;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import edu.stanford.nlp.ie.crf.CRFClassifier;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.ling.TaggedWord;
import edu.stanford.nlp.ling.Word;
import edu.stanford.nlp.tagger.maxent.MaxentTagger;
import qjt.predratings.PathVar;

/**
 * ��һ�����ľ����г�ȡ����Ҫ���term
 * */
public class Extractor4C implements Extractor{
	CRFClassifier<CoreLabel> segmenter;
	MaxentTagger tagger;
	
	private static final String basedir = PathVar.path+"stanford/data";
	private String[] posList={"AD","NN","VV","JJ","VA","NR","P","VE", "DT"};
	HashSet<String> hset;
	
	public Extractor4C(){
		initialize();
		buildSegmenter();
		tagger = new MaxentTagger(PathVar.path+"stanford/models/chinese-nodistsim.tagger");
	}
	private void initialize(){
		hset=new HashSet<String>();
		for(String s:posList){
			hset.add(s);
		}
	}
	/**
	 * ��һ�����ӳ�ȡ������Ҫ���term list
	 * */
	public Vector<TermTag> extract(String line) throws Exception{
		Vector<TermTag> vec = new Vector<TermTag>(); 
		
		List<String> list=segment(line);
		List<HasWord> sent = toHasWordList(list);
	    List<TaggedWord> taggedSent = tagger.tagSentence(sent);
	    for (TaggedWord tw : taggedSent) {
	    	if(hset.contains(tw.tag())){
	    		vec.add(new TermTag(tw.word(),tw.tag()));
	    	}
//	    	System.out.println(tw.word()+" "+tw.tag());
	    }
	    return vec;
	}
	private void buildSegmenter(){
		Properties props = new Properties();
	    props.setProperty("sighanCorporaDict", basedir);
	    // props.setProperty("NormalizationTable", "data/norm.simp.utf8");
	    // props.setProperty("normTableEncoding", "UTF-8");
	    // below is needed because CTBSegDocumentIteratorFactory accesses it
	    props.setProperty("serDictionary", basedir + "/dict-chris6.ser.gz");
	    props.setProperty("inputEncoding", "UTF-8");
	    props.setProperty("sighanPostProcessing", "true");

	    segmenter = new CRFClassifier<>(props);
	    segmenter.loadClassifierNoExceptions(basedir + "/ctb.gz", props);
	}
	private List<String> segment(String line){
	    List<String> segmented = segmenter.segmentString(line);
	    return segmented;
	}
	private List<HasWord> toHasWordList(List<String> list){
		List<HasWord> hlist=new ArrayList<HasWord>();
		for(String s:list){
			hlist.add(new Word(s));
		}
		return hlist;
	}
	public static void main(String[] args){
		Extractor4C e=new Extractor4C();
		String line[]={"���Ǳ��ݵĺܾ���"};
		Vector<TermTag> vec=null;
		
		try {
			for(String s:line){
				vec=e.extract(s);
			}
			for(TermTag s : vec){
				System.out.print(s.term+" "+s.tag);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
	}
	@Override
	public String stem(String token) {
		// �������ģ�û��stem
		return token;
	}
	@Override
	public String getTag(String token) {
		String s=tagger.tagString(token);
		String[] str=s.split("#");
		return str[1];
	}	
}
