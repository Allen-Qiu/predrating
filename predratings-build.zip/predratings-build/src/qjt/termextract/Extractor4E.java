package qjt.termextract;

import java.io.RandomAccessFile;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;

import edu.stanford.nlp.ling.TaggedWord;
import edu.stanford.nlp.process.Morphology;

/**
 * ��һ��Ӣ�ľ����У���ȡ����Ҫ���term
 * */
public class Extractor4E implements Extractor{
	public PhraseTree ptree;
	private HashSet<String> posSet;
	private String[] posList={"JJ","JJR","JJS","NN","NNS","NNP","NNPS","RB","RBR","RBS",
			"VB","VBD","VBG","VBN","VBP","VBZ"};
	private Postagger p;
	
	public Extractor4E(){
		try{
			p = new Postagger();
			buildPMap();
			buildPTree();
		}catch(Exception e){
			
		}
	}
	/**
	 * ���һ���� ��stem
	 * */
	public String stem(String token){
		return p.stem(token);
	}
	/**
	 * ��һ���ʣ�������Ĵ���
	 * */
	public String getTag(String token){
		return p.getTag(token);
	}
	/**
	 * ��һ�����ӳ�ȡ������Ҫ���term list
	 * */
	public Vector<TermTag> extract(String line) throws Exception{
		List<List<TaggedWord>> list;
		Vector<TermTag> vec = new Vector<TermTag>();			// �洢���յ�terms
		list = p.run(line);
		String token;
		String tag;
		Vector<TaggedWord> phrase=new Vector<TaggedWord>();//���ж��Ƿ��Ǵ���ʱ����ʱ�洢
		TermMap tm=TermMap.getInstance();								
		boolean isFirst=true;	
		String tp;
		
		for(List<TaggedWord> sentence : list){
			for(TaggedWord word :sentence){
				token=word.word();
				tag=word.tag().toLowerCase();
				
				if(isFirst){						// ����������жϴ���phrase
					if(ptree.findPrefix(token)){	// ��ĳ�������ǰ׺
						isFirst=false;
						phrase.clear();
						phrase.add(word);
					}else{
						if(posSet.contains(tag)){
							vec.add(new TermTag(tm.getMapTerm(token),tag));
						}
					}
				}else{
					tp=getPhrase(phrase,token);		// ����ǰphrase�е�tokens�͵�ǰ��token���һ������
					if(ptree.find(tp)){				// ��һ������
						vec.add(new TermTag(tm.getMapTerm(tp),tag));
						phrase.clear();
						isFirst=true;
					}else{
						if(ptree.findPrefix(tp)){	// ���Ǵ��鵫��ǰ׺
							phrase.add(word);
						}else{						// ����һ��ǰ׺
							phrase.add(word);
							for(int i=0;i<phrase.size();i++){
								tag=phrase.get(i).tag().toLowerCase();
								token=phrase.get(i).word().toLowerCase();
								if(posSet.contains(tag)){
									vec.add(new TermTag(tm.getMapTerm(token),tag));
								}
							}
							phrase.clear();
							isFirst=true;
						}
					}
				}
				
			}
		}
		return vec;
	}
	/**
	 * ת����A-B-C��ʽ��phrase
	 * */
	private String getPhrase(Vector<TaggedWord> phrase, String token){
		String r="";
		String term;
		for(int i=0;i<phrase.size();i++){
			term=phrase.get(i).word().toLowerCase();
			r+=term+"-";
		}
		return r+token;
	}
	private void buildPMap(){
		posSet=new HashSet<String>();
		for(int i=0;i<posList.length;i++){
			posSet.add(posList[i].toLowerCase());
		}
	}
	private void buildPTree() throws Exception{
		RandomAccessFile raf=new RandomAccessFile("words.txt","r");
		String line;
		Vector<String> vec=new Vector<String>();
		
		while((line=raf.readLine())!=null){
			line=line.trim();
			if(line.startsWith("//")||line.isEmpty()) continue;
			vec.add(line.toLowerCase());
		}
		ptree=new PhraseTree(vec);
		raf.close();
	}
}
