package qjt.termextract;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

import model.GlobalVars;

public class Test {

	public static void main(String[] args) {
		Extractor ext=new Extractor4E();
		String line="Cheesecake Factory is a solid choice";
//		String line="Service wasn't particularly friendly";
		Vector<TermTag> vec;
		try {
			vec=ext.extract(line);
			for(int i=0;i<vec.size();i++){
				System.out.println(vec.get(i).term);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
