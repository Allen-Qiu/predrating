package qjt.predratings;

import java.io.FileInputStream;
import java.util.Properties;

import dataset.MyVector;

/**
 * cumulative logit model
 * -- 2016..8.19 -- J. Qiu
 * */
public class CLM {
	private double b1,b3,b5,b7,a1,a2,a3,a4;
	
	/**
	 *  clm.properties yelp CLM property file
	 *  clm2.properties douban CLM property file
	 * */
	public CLM(String pfile){
		readParameters(pfile);
	}
	public int run(MyVector vec){
		/* XT*beta */
		double val=b1*(vec.nap+1)/(vec.nap+vec.nan+2)+b3*(vec.sp+1)/(vec.sp+vec.sn+2)+
				b5*(vec.tp+1)/(vec.tp+vec.tn+2)+b7*Math.log(vec.len+1);
		
		double p1=1/(1+Math.exp(val-a1));
		double p2=1/(1+Math.exp(val-a2));
		double p3=1/(1+Math.exp(val-a3));
		double p4=1/(1+Math.exp(val-a4));
		
		double[] pr=new double[5];
		pr[4]=1-p4;
		pr[3]=p4-p3;
		pr[2]=p3-p2;
		pr[1]=p2-p1;
		pr[0]=p1;
		
		double max=-1;
		int index=2;
		
		for(int i=0;i<pr.length;i++){
			if(max<pr[i]){
				max=pr[i];
				index=i;
			}
		}
		return index+1;
	}
	private void readParameters(String pfile){
		Properties prop = new Properties();
        try {
			prop.load(new FileInputStream(pfile));
			b1 = Double.parseDouble(prop.getProperty("b1")); 
			b3 = Double.parseDouble(prop.getProperty("b3")); 
			b5 = Double.parseDouble(prop.getProperty("b5"));
			b7 = Double.parseDouble(prop.getProperty("b7"));
			a1 = Double.parseDouble(prop.getProperty("a1"));
			a2 = Double.parseDouble(prop.getProperty("a2"));
			a3 = Double.parseDouble(prop.getProperty("a3"));
			a4 = Double.parseDouble(prop.getProperty("a4"));
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
