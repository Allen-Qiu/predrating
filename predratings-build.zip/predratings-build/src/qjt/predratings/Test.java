package qjt.predratings;

import java.sql.ResultSet;

import dataset.OperateDB;
import model.GlobalVars;
import qjt.termextract.Extractor4C;
import qjt.termextract.Extractor4E;

/**
 * A demo using trained CLM to make a prediction
 * */
public class Test {
	
	public static void main(String[] args) {
		test2();
	}
	private static void test1(){
		RMain rmain=new RMain(new Extractor4C(), new CLM(PathVar.path+"clm2.properties"));
		int ratings;
		OperateDB op=OperateDB.getInstance();
		op.connect(GlobalVars.getInstance().dbName);
		String command="select stars, rtext from reviews order by rid";
		ResultSet rs;
		int stars;
		String review;
		int mae=0;
		int len=0;
		try{
			rs=op.select(command);
			while(rs.next()){
				stars=rs.getInt("stars");
				review=rs.getString("rtext");
				ratings=rmain.run(review);
				mae+=Math.abs(ratings-stars);
				len++;
				if(len%10000==0){
					System.out.println(len);
				}
			}
			System.out.println("mae:"+mae*1.0/len);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * calculate emotion for reviews in DB
	 * */
	private static void test2(){
		OperateDB op=OperateDB.getInstance();
		op.connect(GlobalVars.getInstance().dbName);
		RMain rmain=new RMain(new Extractor4C(), new CLM("clm2.properties"));
		int ratings;
		String command="select rid, contents from movies where stars=100 order by rid";
		ResultSet rs;
		String rid;
		String review;
		String command2;
		int k = 0;
		
		try{
			rs=op.select(command);
			while(rs.next()){
				rid=rs.getString("rid");
				review=rs.getString("contents");
				ratings=rmain.run(review);
				command2 = "update movies set stars="+ratings+ "where rid="+rid;
				op.operate(command2);
				k++;
			}
			System.out.println("size:"+k);
		}catch(Exception e){
			e.printStackTrace();
		}
		op.disconnect();
	}
	private static void test3(){
		RMain rmain=new RMain(new Extractor4E(), new CLM(PathVar.path+"clm.properties"));
		double[] ratings=rmain.run2("t1.txt");
		
		for(int i=0;i<ratings.length;i++){
			System.out.println((i+1)+"-star:"+ratings[i]);
		}
	}
}
