package dataset;

import java.sql.ResultSet;

import model.CStar;
import model.GlobalVars;
import qjt.termextract.Postagger;

/**
 * yelp�е�һЩreview�����POS tagʱ���ڴ������
 * ������Щreview,
 * */
public class Pickup {
	public static void main(String[] args){
		Pickup pick=new Pickup();
		pick.run();
	}
	private void run(){
		Postagger p = new Postagger();
		OperateDB opdb=OperateDB.getInstance();
		opdb.connect(GlobalVars.getInstance().dbName);
		String command="select rid, stars,rtext from reviews where rid>1089373 order by rid";
//		String command="select rid,stars,rtext from reviews where rid=154935";
		ResultSet rs=null;
		String rtext;
		String rid="no";
		boolean has;
		
		try {
			rs = opdb.select(command);
		} catch (Exception e) {
			e.printStackTrace();
		}
		while(true){
			try{
				has=rs.next();
				if(!has) break;
				
				rid = rs.getString("rid");
				rtext = rs.getString("rtext");
				System.out.println(rid);
				p.run(rtext);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		opdb.disconnect();
	}
}
