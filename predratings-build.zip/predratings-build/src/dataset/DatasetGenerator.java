package dataset;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import model.CStar;
import model.GlobalVars;
import qjt.termextract.Extractor;
import qjt.termextract.Extractor4C;
import qjt.termextract.Extractor4E;
import qjt.termextract.TermTag;
 
/**
 * ʹ��qjt.termextract���еķ�������reviewsת����term-pairs��
 * �����������ʵ䣬һ����term����ŵ�ӳ�䣬һ���ӱ�ŵ�SynTerm��ӳ��
 * -- 2016.06 -- J. Qiu
 * ���Ӵ�����������
 * -- 2017.09 -- J. Qiu 
 * */
public class DatasetGenerator {
	OperateDB opdb=OperateDB.getInstance();
	Extractor ext;
	HashMap<String, SynTerm> dic;
	int index;
	
	public static void main(String[] args) {
		DatasetGenerator dg = new DatasetGenerator();
		if(GlobalVars.getInstance().isEng.equals("T")){
			dg.ext=new Extractor4E();
		}else{
			dg.ext=new Extractor4C();
		}
		dg.dic=new HashMap<String, SynTerm>();
		dg.index=1;					// �ʵ��дʵı�ţ���1��ʼ
		
		try {
			dg.buildTrainsetFromSQL();
//			dg.test();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void buildTrainsetFromSQL()throws Exception{
		opdb.connect(GlobalVars.getInstance().dbName);
		String command="select rid, stars,rtext from reviews order by rid";
		ResultSet rs;
		String rid;
		String rtext;
		String rstar;
		String[] str;
		CStar cstar;
		String sentence;
		String r;
		
		try{
			rs = opdb.select(command);
			while(rs.next()){
				sentence="";
				rid = rs.getString("rid");
				rstar = rs.getString("stars");
				cstar = getStar(rstar);
				System.out.println(rid);
				
				if(cstar==null) continue;
				rtext = rs.getString("rtext");
				str = rtext.split(MyRules.subRule);
				
				for(int i=0;i<str.length;i++){
					r = process(str[i]);
					if(r == null||r.isEmpty()) continue;
					sentence += r+";";
				}
				insertDB(rid,rstar,sentence);
			}
			serialize();
		}catch(Exception e){
			e.printStackTrace();
		}
		opdb.disconnect();
	}
	private void insertDB(String rid, String cstar, String line) throws Exception{
		String command = "insert into termpairs(rid,stars,comment) values('"+rid+"','"+cstar+"','"+line+"'"+")";
		opdb.operate(command);
//		System.out.println(rid+":"+cstar+":"+line);
	}
	private CStar getStar(String star){
		int k;
		try{
			k = Integer.parseInt(star.trim());
			switch (k){
				case 1: return CStar.ONE;
				case 2:	return CStar.TWO;
				case 3:	return CStar.THR;
				case 4:	return CStar.FOU;
				case 5:	return CStar.FIV;
			}
		}catch(Exception e){
			return null;
		}
		return null;
	}
	/**
	 * ��һ������ת����term-pairs���б�, �������ʵ�
	 * */
	private String process(String line) throws Exception{
		Vector<Integer> termList = new Vector<Integer>();
		Integer[] list;
		Vector<TermTag> vec=ext.extract(line);
		String token;
		SynTerm syn;
		String tag;
		String sToken;
		TermTag ttag;
		
		for(int i=0;i<vec.size();i++){
			ttag=vec.get(i);
			token=ttag.term;
			sToken=ext.stem(token);
			syn=dic.get(sToken);
			if(syn==null){
				tag=ttag.tag;
				syn=new SynTerm(sToken, tag, index++);
				dic.put(sToken, syn);
			}
			termList.add(syn.index);
		}
		
		list = new Integer[termList.size()];
		termList.toArray(list);
		return buildSentence(list);
	}
	private String buildSentence(Integer[] termList){
		int row, col;
		String result="";
		
		for(int i=0;i<termList.length-1;i++){
			row = termList[i];
			for(int j=i+1;j<termList.length;j++){
				col = termList[j];
				if(row == col) continue;
				result +="{"+row+","+col+"}";
			}
		}
		return result;
	}
	
	/**
	 * ���ʵ�dic���л����
	 * */
	private void serialize(){
		try{
			ObjectOutputStream ModelOut=
				new ObjectOutputStream(
					new FileOutputStream(GlobalVars.getInstance().dicName));
			ModelOut.writeObject(dic);;
			ModelOut.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
