package analysis;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import dataset.SynTerm;

import java.util.Set;
import java.util.TreeMap;

import model.Element2;

/**
 * ����mu, ���������ߵ�terms
 * */
public class Ana1 {
	TreeMap<Integer, Element2> mu;
	HashMap<Integer, SynTerm> inverseDic;
	int size=30;
	
	public static void main(String[] args) {
		Ana1 ana=new Ana1();
		ana.run();
		
	}
	public void run(){
		read();
		sort();
	}
	private void sort(){
		Set<Entry<Integer, Element2>> set=mu.entrySet();
		Iterator<Entry<Integer, Element2>>  it=set.iterator();
		Entry<Integer, Element2> entry;
		MyList plist=new MyList(size, true);
		MyList nlist=new MyList(size, false);
		
		while(it.hasNext()){
			entry=it.next();
			plist.insert(entry);
			nlist.insert(entry);
		}
		plist.print(inverseDic);
		nlist.print(inverseDic);
		
	}
	private void read(){
		ObjectInputStream ModelIn;
		
		try{
			ModelIn=new ObjectInputStream(
					new FileInputStream("global_mu_polarity.out"));
			mu=(TreeMap<Integer, Element2>)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		try{
			ModelIn=new ObjectInputStream(
						new FileInputStream("dic/inversdic.out"));
			inverseDic=(HashMap<Integer, SynTerm>)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
