package analysis;

import java.util.HashMap;
import java.util.LinkedList;

import dataset.SynTerm;
import model.Element;
import model.SMatrix;
import model.TermPair;

public class MyList2 {
	private LinkedList<TermPair> list;
	private int size;
	private final int POS=0, NEG=1;
	private boolean forPOS;
	private SMatrix sm;
	
	public MyList2(int size, boolean forPOS, SMatrix sm){
		this.size=size;
		this.forPOS=forPOS;
		this.sm=sm;
		list=new LinkedList<TermPair>();
	}
	public void insert(TermPair tp){
		int start=0, end=list.size()-1;
		int k;
		double pscore, cscore,qscore, kscore;
		
		if(list.size()==0){
			list.add(tp);
			return;
		}
		
		cscore=getScore(tp);
		pscore=getScore(list.get(start));
		qscore=getScore(list.get(end));
		
		if(cscore>pscore){
			list.addFirst(tp);
			remove();
			return;
		}
		if(cscore<qscore){
			list.addLast(tp);
			remove();
			return;
		}
		/* �۰���� */
		while(true){
			k=(end+start)/2;
			kscore=getScore(list.get(k));
			
			if(cscore==kscore){
				break;
			}else if(cscore>kscore){
				end=k;
			}else if(cscore<kscore){
				start=k;
			}
			if(start==end||start+1==end){
				k=end;
				break;
			}
		}
		
		list.add(k, tp);
		remove();
	}
	private void remove(){
		if(list.size()>size){
			list.removeLast();
		}
	}
	private double getScore(TermPair tp){
		int contextIndex=tp.contextIndex;
		int coreIndex=tp.coreIndex;
		
		Element ele=sm.get(contextIndex, coreIndex);
		if(ele==null){
			ele=sm.get(coreIndex, contextIndex);
		}
		return calcScore(ele);
	}
	private double calcScore(Element ele){
		float pscore=ele.get(POS);
		float nscore=ele.get(NEG);
//		float sum;
//		sum=pscore+nscore;
//		pscore=pscore/sum;
//		nscore=nscore/sum;
		
		if(forPOS){
			return Math.log(pscore+1)-Math.log(nscore+1);
//			return pscore-nscore;
		}else{
			return Math.log(nscore+1)-Math.log(pscore+1);
//			return nscore-pscore;
		}
	}
	public void print(HashMap<Integer, SynTerm> inverseDic){
		TermPair tp;
		Element ele;
		SynTerm syn1,syn2;
		
		
		for(int i=0;i<list.size();i++){
			tp=list.get(i);
			ele=sm.get(tp.contextIndex, tp.coreIndex);

			if(ele==null){
				ele=sm.get(tp.coreIndex, tp.contextIndex);
			}
			syn1=inverseDic.get(tp.coreIndex);
			syn2=inverseDic.get(tp.contextIndex);
			System.out.println(syn1.term+"---"+syn2.term+":"+ele.get(POS)+"-"+ele.get(NEG));
		}
		System.out.println("--- end ---");
	}
	public static void main(String[] args) {
		
	}
}
