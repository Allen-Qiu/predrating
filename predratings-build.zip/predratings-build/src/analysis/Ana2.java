package analysis;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;

import dataset.SynTerm;
import model.SMatrix;
import model.TermPair;

/**
 * lamda, term-pairs
 * */
public class Ana2 {
	SMatrix lamda;
	HashMap<Integer, SynTerm> inverseDic;
	int size=20;
	
	public static void main(String[] args){
		Ana2 ana=new Ana2();
		ana.run();
	}
	public void run(){
		read();
		sort();
	}
	private void sort(){
		ArrayList<TermPair> list=lamda.getCollection();
		MyList2 plist=new MyList2(size, true, lamda);
		MyList2 nlist=new MyList2(size, false, lamda);
		TermPair tp;
		
		for(int i=0;i<list.size();i++){
			tp=list.get(i);
			plist.insert(tp);
			nlist.insert(tp);
		}
		plist.print(inverseDic);
		nlist.print(inverseDic);
	}
	private void read(){
		ObjectInputStream ModelIn;
		
		try{
			ModelIn=new ObjectInputStream(
					new FileInputStream("D:/qjt/global_lamda_polarity.out"));
			lamda=(SMatrix)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		try{
			ModelIn=new ObjectInputStream(
						new FileInputStream("dic/inversdic.out"));
			inverseDic=(HashMap<Integer, SynTerm>)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
