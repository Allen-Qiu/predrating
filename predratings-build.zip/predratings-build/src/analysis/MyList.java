package analysis;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import dataset.SynTerm;
import model.Element2;

public class MyList {
	private LinkedList<Entry<Integer, Element2>> list;
	private int size;
	private final int POS=0, NEG=1;
	private boolean forPOS;
	
	public MyList(int size, boolean forPOS){
		this.size=size;
		this.forPOS=forPOS;
		list=new LinkedList<Entry<Integer, Element2>>();
	}
	public void insert(Entry<Integer, Element2> entry){
		int start=0, end=list.size()-1;
		int k;
		double pscore, cscore,qscore, kscore;
		
		if(list.size()==0){
			list.add(entry);
			return;
		}
		
		cscore=getScore(entry);
		pscore=getScore(list.get(start));
		qscore=getScore(list.get(end));
		
		if(cscore>pscore){
			list.addFirst(entry);
			remove();
			return;
		}
		if(cscore<qscore){
			list.addLast(entry);
			remove();
			return;
		}
		/* �۰���� */
		while(true){
			k=(end+start)/2;
			kscore=getScore(list.get(k));
			
			if(cscore==kscore){
				break;
			}else if(cscore>kscore){
				end=k;
			}else if(cscore<kscore){
				start=k;
			}
			if(start==end||start+1==end){
				k=end;
				break;
			}
		}
		
		list.add(k, entry);
		remove();
	}
	private void remove(){
		if(list.size()>size){
			list.removeLast();
		}
	}
	private double getScore(Entry<Integer, Element2> entry){
		Element2 ele=entry.getValue();
		return calcScore(ele);
	}
	private double calcScore(Element2 ele){
		float pscore=ele.get(POS);
		float nscore=ele.get(NEG);
		
		if(forPOS){
			return Math.log(pscore+1)-Math.log(nscore+1);
		}else{
			return Math.log(nscore+1)-Math.log(pscore+1);
		}
	}
	public void print(){
		Entry<Integer, Element2> entry;
		Element2 ele;
		
		for(int i=0;i<list.size();i++){
			entry=list.get(i);
			ele=entry.getValue();
			System.out.println(entry.getKey()+":"+ele.get(POS)+"-"+ele.get(NEG));
		}
		System.out.println("--- end ---");
	}
	public void print(HashMap<Integer, SynTerm> inverseDic){
		Entry<Integer, Element2> entry;
		Element2 ele;
		int key;
		SynTerm syn;
		
		for(int i=0;i<list.size();i++){
			entry=list.get(i);
			ele=entry.getValue();
			key=entry.getKey();
			syn=inverseDic.get(key);
			System.out.println(syn.term+":"+ele.get(POS)+"-"+ele.get(NEG));
		}
		System.out.println("--- end ---");
	}
	public static void main(String[] args) {
		MyList m=new MyList(5, true);
		MyEntry<Integer, Element2> entry;
		Element2 ele=new Element2();
		
		ele=new Element2();
		ele.set(m.POS, 8);
		ele.set(m.NEG, 3);
		entry=new MyEntry<Integer, Element2>(3, ele);
		m.insert(entry);
		
		ele=new Element2();
		ele.set(m.POS, 7);
		ele.set(m.NEG, 4);
		entry=new MyEntry<Integer, Element2>(4, ele);
		m.insert(entry);
		m.print();
		
		ele=new Element2();
		ele.set(m.POS, 6);
		ele.set(m.NEG, 5);
		entry=new MyEntry<Integer, Element2>(5, ele);
		m.insert(entry);
		m.print();
		
		ele=new Element2();
		ele.set(m.POS, 5);
		ele.set(m.NEG, 6);
		entry=new MyEntry<Integer, Element2>(6, ele);
		m.insert(entry);
		m.print();
		
		ele=new Element2();
		ele.set(m.POS, 9);
		ele.set(m.NEG, 2);
		entry=new MyEntry<Integer, Element2>(2, ele);
		m.insert(entry);
		m.print();
		
		ele=new Element2();
		ele.set(m.POS, 4);
		ele.set(m.NEG, 7);
		entry=new MyEntry<Integer, Element2>(7, ele);
		m.insert(entry);
		m.print();
		
		ele=new Element2();
		ele.set(m.POS, 3);
		ele.set(m.NEG, 8);
		entry=new MyEntry<Integer, Element2>(8, ele);
		m.insert(entry);
		m.print();
		
		ele=new Element2();
		ele.set(m.POS, 2);
		ele.set(m.NEG, 9);
		entry=new MyEntry<Integer, Element2>(9, ele);
		m.insert(entry);
		m.print();
		
		ele=new Element2();
		ele.set(m.POS, 10);
		ele.set(m.NEG, 1);
		entry=new MyEntry<Integer, Element2>(1, ele);
		m.insert(entry);
		m.print();
	}
}
