package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 * main program for training model
 * ʹ��termpairs.txt��terms.txt�ļ���ѵ��
 * */
public class Test {
	
	public static void main(String[] args) {
		Test t = new Test();
		int k=40;
//		t.test(k);	
		t.test2(k);
	}
	/**
	 * training lamda model
	 * */
	private void test(int k){
		String args[]={};
		
		for(int i=0;i<k;i++){
			if(i==0){
				Resample.main(new String[]{"first","lamda"});
			}else{
				Resample.main(new String[]{"others","lamda"});
			}
			
			TrainGlobalModel gtrain = new TrainGlobalModel();
			
			try{
				if(i==0){
					gtrain.run(true);
				}else{
					gtrain.run(false);
				}
				ObjectOutputStream ModelOut=
					new ObjectOutputStream(
						new FileOutputStream("global_lamda_polarity.out"));
				ModelOut.writeObject(gtrain.lamda);
				ModelOut.close();
			}catch(Exception e){
				e.printStackTrace();
			}
			Exp.main(args);
			System.out.println("----- "+i+" -----");
		}
	}
	/**
	 * Ϊmu model����ѵ���Ͳ���
	 * */
	private void test2(int k){
		String args[]={};
		
		for(int i=0;i<k;i++){
			if(i==0){
				Resample.main(new String[]{"first","mu"});
			}else{
				Resample.main(new String[]{"others","mu"});
			}
			TrainMuModel gtrain = new TrainMuModel();
			
			
			try{
				if(i==0){
					gtrain.run(true);
				}else{
					gtrain.run(false);
				}
				
				/* serialization */
				ObjectOutputStream ModelOut=
					new ObjectOutputStream(
						new FileOutputStream("global_mu_polarity.out"));
				ModelOut.writeObject(gtrain.mu);
				ModelOut.close();
			}catch(Exception e){
				e.printStackTrace();
			}
			
			Exp2.main(args);
			System.out.println("----- "+i+" -----");
		}
	}
}
