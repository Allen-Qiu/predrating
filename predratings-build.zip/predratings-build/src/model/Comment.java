package model;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Comment {
	private int rid;
	private CStar cstar;
	private List<TermPair> tpair;  
	
	public Comment(int rid, String star, String review){
		this.rid = rid;
		tpair = new ArrayList<TermPair>();
		cstar = getStar(star);
		parse(review);
	}
	public CStar getCStar(){
		return cstar;
	}
	public List<TermPair> getTPair(){
		return tpair;
	}
	public int getRid(){
		return rid;
	}
	private CStar getStar(String star){
		int k;
		try{
			k = Integer.parseInt(star.trim());
			switch (k){
			case 1: return CStar.ONE;
			case 2:	return CStar.TWO;
			case 3:	return CStar.THR;
			case 4:	return CStar.FOU;
			case 5:	return CStar.FIV;
			}
		}catch(Exception e){
			return null;
		}
		return null;
	}
	private void parse(String review){
		String core, context;
//		System.out.println(review);
		
		String regex="\\{(\\d+?),(\\d+?)\\}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(review);
		while(m.find()){
			core = m.group(1);
			context = m.group(2);
			add(core, context);
		}
	}
	public static void main(String[] args){
		String str="{1,2},{11,12},{111,112},{1111,11112},{111111,111112},";
		Comment record = new Comment(1,"5",str);
	}
	private void add(String core, String context){
		int iCore;
		int iContext;
		try{
			iCore = Integer.parseInt(core);
			iContext = Integer.parseInt(context);
			tpair.add(new TermPair(iCore,iContext));
		}catch(Exception e){
			return;
		}
	}
}

