package model;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.List;

/**
 * only use lamda learned for polarity to make prediction
 * */
public class LamdaModel {
	public SMatrix lamda;
	final int POS=0, NEG=1;
	private final int[] POLARS={POS,NEG};
	
	public LamdaModel(){
		read();
	}
	public int predict(Comment comment){
		double[] polars = calcProb(comment);
		double val,max=0;
		int r=-1;
		
		for(int i=0;i<POLARS.length;i++){
			val=polars[i];
			if(val>max) {
				r=i;
				max = val;
			}
		}
		return r;
	}
	private double[] calcProb(Comment comment){
		TermPair tpair;
		int core, context;
		Element lele;
		double[] lSum = new double[POLARS.length];
		float sum=0;
		List<TermPair> list = comment.getTPair();
		
		for(int i=0; i<list.size();i++){
			tpair = list.get(i);
			core = tpair.coreIndex;
			context = tpair.contextIndex;
			lele = lamda.get(core, context);
			if(lele==null){
				lele = lamda.get(context, core);
			}
			if(lele==null) continue;
			for(int j=0;j<POLARS.length;j++){
				lSum[j]+=lele.get(j)/(lele.get(POS)+lele.get(NEG));
			}
//			lSum[POS]+=(nCount*1.0/rCount)*lele.get(POS)/(lele.get(POS)+lele.get(NEG));
//			lSum[NEG]+=(pCount*1.0/rCount)*lele.get(NEG)/(lele.get(POS)+lele.get(NEG));
		}
		for(int i=0; i<lSum.length; i++){sum += lSum[i];}
		for(int i=0; i<lSum.length; i++){lSum[i] /= sum;}
		return lSum;
	}
	private void read(){
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream("global_lamda_polarity.out"));
			lamda = (SMatrix)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
