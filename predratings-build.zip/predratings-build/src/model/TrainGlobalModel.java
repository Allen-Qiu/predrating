package model;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import java.util.Properties;
import java.util.TreeMap;

/**
 * use with Resample.java to deal with imbalance class.
 * */
public class TrainGlobalModel{
	public SMatrix lamda;					// row is core word, column is context word 
	private TupleCount tCount;
	private double deltaMu, deltaLamda;
	private int iter;
	private double alpha, beta;
	private final int POS=0, NEG=1;
	private final int[] POLARS={POS,NEG};
	public static Dataset dataset = new Dataset();
	
	public void run(boolean isFirst) throws Exception{
		SMatrix fk;
		TermPair termpair;
		int core, context;
		CStar star;
		Element ele, lele, fele, smele, mele;
		double[] sprob;
		lamda = new SMatrix();
		fk = new SMatrix();			// fk is first part of lamda grad
		readParameters();
		SMatrix pfk;
		Comment comment;
		List<TermPair> tpairs;
		Integer loop;
		
		readTupleCount();
		
		/* initialization */
		while((comment = dataset.next())!=null){
			loop = tCount.get(comment.getRid());
			if(loop==null) continue;

			star = comment.getCStar();
			tpairs = comment.getTPair();
			
			for(int iLoop=0 ;iLoop<loop;iLoop++){
				for(int i=0;i<tpairs.size();i++){
					termpair = tpairs.get(i);
					core = termpair.coreIndex;
					context = termpair.contextIndex;
					
					ele = fk.get(core, context);
					if (ele != null){
						ele.inc(map(star));
					}else{
						ele=fk.get(context, core);
						if(ele==null){
							ele = new Element();
							ele.set(map(star), 1);
							fk.put(context, core, ele);
						}else{
							ele.inc(map(star));
						}
					}
					
					ele = lamda.get(core, context);
					if(ele != null){
						if(ele.get(map(star))==0){
							ele.set(map(star), (float)Math.random());						
						}
					}else{
						ele = lamda.get(context, core);
						if(ele==null){
							ele = new Element();
							ele.set(map(star), (float)Math.random());
							lamda.put(context, core, ele);
						}else{
							if(ele.get(map(star))==0){
								ele.set(map(star), (float)Math.random());						
							}
						}
					}
				}
			}
		}
		if(!isFirst){
			lamda=readLamda();
		}
		
		/* train iteration */
		float val;
		for(int it =0; it<iter;it++){
			pfk = new SMatrix();				  		// pfk is second part of lamda grad
			
			while((comment = dataset.next())!=null){		
				loop = tCount.get(comment.getRid());
				if(loop==null) continue;

				star = comment.getCStar();
				sprob = calcProb(comment);		    	// p(l'|s_n)
				tpairs=comment.getTPair();
				
				for(int iLoop=0 ;iLoop<loop;iLoop++){
					
					/* update second part of lamda grad, respectively */
					for(int i=0;i<tpairs.size();i++){
						termpair=tpairs.get(i);
						core = termpair.coreIndex;
						context = termpair.contextIndex;
						ele = pfk.get(core, context);			// lamda grad
						if(ele == null){
							ele=pfk.get(context, core);
							if(ele==null){
								ele = new Element();
								pfk.put(core, context, ele);
							}
						}
						val = ele.get(map(star));			// f_k(core, context, label)
						val += sprob[map(star)];
						ele.set(map(star), val);
					}
				}
			}
			
			/* traverse each of lamda, then update */
			ArrayList<TermPair> tlist=fk.getCollection();
			float grad;
			for(int i=0;i<tlist.size();i++){
				termpair=tlist.get(i);
				core = termpair.coreIndex;
				context = termpair.contextIndex;
				ele = pfk.get(core, context);
				if(ele == null){
					ele = pfk.get(context, core);
					if(ele==null){
//						System.out.println("test: there exists empty termpair");
						continue;
					}
				}
				lele = lamda.get(core, context);
				if(lele==null){
					lele = lamda.get(context, core);
				}
				fele = fk.get(core, context);
				if(fele==null){
					fele = fk.get(context, core);
				}
				for(int j=0; j<POLARS.length;j++){
					if(fele.get(j)<=0) continue;
					grad = fele.get(j)-ele.get(j);
					if(grad<0){
						System.out.println(grad);
					}
//					grad = grad - ����;
					val = lele.get(j);
					val = (float)(val + alpha*grad);
					lele.set(j, val);
				}
			}
			
			/* calculate log likelihood */
			float likelihood = 0;
			while((comment = dataset.next())!=null){		
				loop = tCount.get(comment.getRid());
				if(loop==null)continue;
				
				star = comment.getCStar();
				sprob = calcProb(comment);
				
				for(int iLoop=0 ;iLoop<loop;iLoop++){
					
					if(sprob[map(star)]>0){
						likelihood += Math.log(sprob[map(star)]);
					}
				}
			}
			likelihood = -likelihood;
			System.out.println("iter "+it+":"+likelihood);
		}
	}
	private SMatrix readLamda(){
		SMatrix localLamda=null;
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream("global_lamda_polarity.out"));
			localLamda = (SMatrix) ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return localLamda;
	}
	private void readTupleCount() {
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream("sampling/tuplecount.out"));
			tCount = (TupleCount)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * calculate the probability of assigning label to sentence, p(l'|s_n)
	 * */
	private double[] calcProb(Comment comment){
		TermPair tpair;
		int core, context;
		Element lele;
		double[] lSum = new double[POLARS.length];
		float sum=0;
		List<TermPair> list = comment.getTPair();
		
		for(int i=0; i<list.size();i++){
			tpair = list.get(i);
			core = tpair.coreIndex;
			context = tpair.contextIndex;
			lele = lamda.get(core, context);
			if(lele==null){
				lele = lamda.get(context, core);
			}
			if(lele==null) continue;
			for(int j=0;j<POLARS.length;j++){
				lSum[j]+=lele.get(j);
			}
		}
		for(int i=0; i<lSum.length; i++){sum += lSum[i];}
		for(int i=0; i<lSum.length; i++){lSum[i] /= sum;}
		return lSum;
	}
	private int map(CStar cstar){
		if(cstar==CStar.FIV||cstar==CStar.FOU) return POS;
		if(cstar==CStar.ONE||cstar==CStar.TWO) return NEG;
		return -1;
	}

	private void readParameters(){
		Properties prop = new Properties();
        try {
			prop.load(new FileInputStream("senticrf_parameter.properties"));
			alpha = Double.parseDouble(prop.getProperty("alpha")); 
			beta = Double.parseDouble(prop.getProperty("beta")); 
			iter = Integer.parseInt(prop.getProperty("iter"));
			deltaLamda = Integer.parseInt(prop.getProperty("deltalamda"));
			deltaMu = Integer.parseInt(prop.getProperty("deltamu"));
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
