package model;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

/**
 * reading trainset (terms file) to train model with only status function.
 * This model only train a model with polarity, but not ratings.
 * we regard reviews with 1 or 2 rating as negative comments, and those with 4 or 5 as positive comments
 * -- 2015.12 -- Qiu
 * */
public class TrainMuModel {
	public TreeMap<Integer, Element2> mu;
	private double deltaMu, deltaLamda;
	private TupleCount tCount;
	private int iter;
	private double alpha, beta;
	private final int POS=0, NEG=1;
	private final int[] POLARS={POS,NEG};
	static Dataset2 dataset = new Dataset2(false);
	
	/**
	 * ��һ������Ҫ��mu��ʼ�����������Ƕ�����һ�δ��л������mu
	 * */
	public void run(boolean isFirst) throws Exception{
		System.out.println("dataset size:"+dataset.size());
		CStar star;
		Element2 ele, smele, mele;
		double[] sprob;
		TreeMap<Integer, Element2> sm  = new TreeMap<Integer, Element2>();	// state function, count of 
		mu  = new TreeMap<Integer, Element2>();								// coefficient of sm
		TreeMap<Integer, Element2> psm;
		readParameters();
		Vector<Integer> terms;
		Review comment;
		Integer term;
		Integer loop;
		
		readTupleCount();

		/* initialization, mu */
		while((comment = dataset.next())!=null){
			loop = tCount.get(comment.getRid());
			if(loop==null) continue;
			
			star = comment.getCStar();
			terms = comment.getTerms();
			
			for(int iLoop=0 ;iLoop<loop;iLoop++){
				for(int i=0;i<terms.size();i++){
					term = terms.get(i);
					put2sm(sm, mu, term, star);
				}
			}
		}
		
		if(!isFirst){
			mu=readMu();
		}
		System.out.println("size:"+mu.size());
		/* train iteration */
		float val;
		for(int it =0; it<iter;it++){
			psm = new TreeMap<Integer, Element2>();		// psm is second part of mu grad
			
			while((comment = dataset.next())!=null){	
				loop = tCount.get(comment.getRid());
				if(loop==null) continue;
				
				star = comment.getCStar();
				sprob = calcProb(comment);		    	// p(l'|s_n)
				terms=comment.getTerms();
				
				for(int iLoop=0 ;iLoop<loop;iLoop++){
					
					/* update second part of mu grad, respectively */
					for(int i=0;i<terms.size();i++){
						term=terms.get(i);
						smele = psm.get(term); 		    		// mu grad
						if(smele == null){
							smele = new Element2();
							psm.put(term, smele);
						}
						val = smele.get(map(star));			// s_m(core, label)
						val += sprob[map(star)];
						smele.set(map(star), val);
					}
				}
			}
			
			/* traverse each of mu, then update */
			float grad;
			Set<Entry<Integer, Element2>> set = sm.entrySet();
			Iterator<Entry<Integer, Element2>> iterator = set.iterator();
			Entry<Integer, Element2> entry;
			int index;
			
			while(iterator.hasNext()){
				entry = iterator.next();
				index = entry.getKey();
				ele   = entry.getValue();
				smele = psm.get(index);
				mele  = mu.get(index);
				
				for(int i=0;i<POLARS.length;i++){
					if(ele.get(i)<=0) continue;
					grad = ele.get(i)-smele.get(i);
					val  = mele.get(i);
					val  = (float)(val + beta*grad);
					mele.set(i, val);
				}
			}
			
			/* calculate log likelihood */
			float likelihood = 0;
			while((comment = dataset.next())!=null){	
				loop = tCount.get(comment.getRid());
				if(loop==null)continue;
				
				star = comment.getCStar();
				for(int iLoop=0 ;iLoop<loop;iLoop++){
					sprob = calcProb(comment);		    	// p(l'|s_n)
					
					if(sprob[map(star)]>0){
						likelihood += Math.log(sprob[map(star)]);
					}
				}
			}
			likelihood = -likelihood;
			System.out.println("iter "+it+":"+likelihood);
		}
	}
	private int map(CStar cstar){
		if(cstar==CStar.FIV||cstar==CStar.FOU) return POS;
		if(cstar==CStar.ONE||cstar==CStar.TWO) return NEG;
		return -1;
	}
	/**
	 * build state function sm and initialize mu.
	 * At fact, it builds first part of mu grad.
	 * */
	private void put2sm(TreeMap<Integer, Element2> sm, 
						TreeMap<Integer, Element2> mu, 
						int term,
						CStar star){
		int core = term;
		Element2 ele;
		
		ele = sm.get(core);
		if(ele == null){
			ele = new Element2();
			ele.set(map(star), 1);
			sm.put(core, ele);
		}else{
			ele.inc(map(star));
		}
		
		ele = mu.get(core);
		if(ele == null){
			ele = new Element2();
			mu.put(core, ele);
			ele.set(map(star), (float)Math.random());
		}
		else{
			if(ele.get(map(star))==0){
				ele.set(map(star), (float)Math.random());
			}
		}
		
	}
	/**
	 * calculate the probability of assigning label to sentence, p(l'|s_n)
	 * */
	private double[] calcProb(Review comment){
		int term;
		Element2 mele;
		double[] lSum = new double[POLARS.length];
		float sum=0;
		Vector<Integer> list = comment.getTerms();
		
		for(int i=0; i<list.size();i++){
			term = list.get(i);
			mele = mu.get(term);
//			if(mele==null) continue;
			
			for(int j=0;j<POLARS.length;j++){
				lSum[j]+=mele.get(j);
			}
		}
		for(int i=0; i<lSum.length; i++){sum += lSum[i];}
		for(int i=0; i<lSum.length; i++){lSum[i] /= sum;}
		return lSum;
	}
	
	private void readTupleCount() {
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream("sampling/tuplecount.out"));
			tCount = (TupleCount)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	private TreeMap<Integer, Element2> readMu(){
		TreeMap<Integer, Element2> localmu=null;
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream("global_mu_polarity.out"));
			localmu = (TreeMap<Integer, Element2>) ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return localmu;
	}
	private void readParameters(){
		Properties prop = new Properties();
        try {
			prop.load(new FileInputStream("senticrf_parameter.properties"));
			alpha = Double.parseDouble(prop.getProperty("alpha")); 
			beta = Double.parseDouble(prop.getProperty("beta")); 
			iter = Integer.parseInt(prop.getProperty("iter"));
			deltaLamda = Integer.parseInt(prop.getProperty("deltalamda"));
			deltaMu = Integer.parseInt(prop.getProperty("deltamu"));
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
