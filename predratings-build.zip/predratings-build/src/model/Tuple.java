package model;
/**
 * One tuple (record)
 * */
public class Tuple implements java.io.Serializable{
	public int rid;
	public double prob;		// sampling probability of the tuple. 
	public double aProb;	// aggregated probability
	public boolean isErr;	// true means the tuple is misclassified in last prediction.
	
	public Tuple(int rid, double prob, double aProb){
		this.rid = rid;
		this.prob = prob;
		this.aProb = aProb;
		this.isErr = false;
	}
}
