package model;

/**
 * comment2 use it
 * */
public class Entry {
	int rid;
	String review;
	String stars;
	public Entry(int rid, String review, String stars){
		this.rid = rid;
		this.review = review;
		this.stars = stars;
	}
}
