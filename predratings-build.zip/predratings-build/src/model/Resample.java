package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import model.CStar;

/**
 * calculate the probability of sampling tuples. Build TupleCount object and serialization.
 * TrainCRFModel8.java read tuplecount and use it to decide the number of one tuple should be use.
 * prediction/Exp7.java update plist(psampling.out) and nlist(nsampling.out)  
 * 
 * steps:
 * 1. initialize plist and nlist.
 * 2. in first time, we manully set tuplecount(sampling2).
 * 3. run TrainCRFModel8
 * 4. run Exp7
 * 5. run Resample (read and sampling)
 * 6. goto 3
 * 
 * -- 2015.12 -- Qiu
 * */
public class Resample {
	ArrayList<Tuple> plist,nlist;		// preserve the probability of sampling every tuple, Exp7 update it
	private String tpfile;
	private TupleCount tCount;			// preserve the count of sampling every tuple, TranCRFodel8.java read it.
	
	/**
	 * tpfile is train file
	 * */
	public Resample(String tpfile){
		this.tpfile = tpfile;
		tCount = new TupleCount();
		plist = new ArrayList<Tuple>();
		nlist = new ArrayList<Tuple>();
		
	}
	/**
	 * at first time, use method of sampling2; then switch to sampling
	 * */
	public void run(boolean isFirst){
		if(isFirst){
			empty();
		}
		read();
		if(isFirst){
			
			sampling2();
		}else{
			sampling();
		}
	}
	/**
	 * at first time, empty folder "sampling"
	 * */
	private void empty(){
		File dir = new File("sampling");
		File[] flist = dir.listFiles();
		
		for(File f : flist){
			f.delete();
		}
	}
	/**
	 * sampling to generate TupleCount
	 * */
	private void sampling(){
		int num = plist.size()>nlist.size()?plist.size():nlist.size();
		double val;
		int index;
		Integer tc;
		Tuple tuple;
		System.out.println("-- run sampling --");
		update();
		for(int i=0;i<num;i++){		// the number of sampling
			val = Math.random();
			index = hit(plist,val);
			tuple = plist.get(index);
			tc = tCount.get(tuple.rid);
			if(tc==null){
				tCount.put(tuple.rid, 1);
			}else{
				tCount.put(tuple.rid,tc+1);
			}
			
			val = Math.random();
			index = hit(nlist,val);
			tuple = nlist.get(index);
			tc = tCount.get(tuple.rid);
			if(tc==null){
				tCount.put(tuple.rid, 1);
			}else{
				tCount.put(tuple.rid,tc+1);
			}
		}
		serialize();
	}
	/**
	 * manually set count 
	 * */
	private void sampling2(){
		Tuple tuple;
		//TODO: ������Щ����, �ֶ����ø���������������������ΪYelpѵ������ˣ�Ӧ�øĳ��Զ����á�
		System.out.println("-- run sampling2 --");
		int size = plist.size()>nlist.size()?plist.size():nlist.size();
		
		for(int i=0;i<size;i++){
			if(i<plist.size()){
				tuple = plist.get(i);
				tCount.put(tuple.rid, 1);
			}
			if(i<nlist.size()){
				tuple = nlist.get(i);
				tCount.put(tuple.rid, 2);
			}
		}
		serialize();
	}
	private void serialize(){
		try{
			ObjectOutputStream ModelOut=
				new ObjectOutputStream(
					new FileOutputStream("sampling/tuplecount.out"));
			ModelOut.writeObject(tCount);
			ModelOut.close();
			
			ModelOut=new ObjectOutputStream(
					new FileOutputStream("sampling/psampling.out"));
			ModelOut.writeObject(plist);
			ModelOut.close();
			
			ModelOut=new ObjectOutputStream(
					new FileOutputStream("sampling/nsampling.out"));
			ModelOut.writeObject(nlist);
			ModelOut.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	/**
	 * pick up index of sampling
	 * */
	private int hit(ArrayList<Tuple> list, double val){
		int start=0, end=list.size()-1;
		int index;
		double sVal, eVal, iVal;
		
		while(true){
			if(start+1==end)return end;
			sVal = list.get(start).aProb;
			eVal = list.get(end).aProb;
			if(val<sVal){
				return start;
			}
			if(val>eVal){
				return end;
			}
			
			index = (int)((start+end)/2.0);
			iVal = list.get(index).aProb;
			
			if(iVal==val){
				return index;
			}else if(iVal<val){
				start = index;
			}else{
				end = index;
			}
		}
	}
	/**
	 * update weights according to isErr of tuple. Use it before sampling.
	 * */
	private void update(){
		Tuple tuple;
		double erate = calcErrRate();
		double s1=0, s2=0;
		double naProb=0, paProb=0;
		int size = plist.size()>nlist.size()?plist.size():nlist.size();
//		double pmin = 10, pmax = 0, nmin = 10, nmax = 0;
		
		for(int i=0;i<size;i++){
			if(i<plist.size()){
				tuple = plist.get(i);
//				if(tuple.prob>pmax)pmax = tuple.prob;
//				if(tuple.prob<pmin)pmin = tuple.prob;
				if(tuple.isErr){
					tuple.prob *= 1 + erate; 
				}
				s1+=tuple.prob;
			}
			if(i<nlist.size()){
				tuple = nlist.get(i);
//				if(tuple.prob>nmax)nmax = tuple.prob;
//				if(tuple.prob<nmin)nmin = tuple.prob;
				if(tuple.isErr){
					tuple.prob *= 1 + erate;
				}
				s2+=tuple.prob;
			}
		}
//		System.out.println("pmax:"+pmax+" nmax:"+nmax);
//		System.out.println("pmin:"+pmin+" nmin:"+nmin);
		
		/* normalizing */
		for(int i=0;i<size;i++){
			if(i<plist.size()){
				tuple = plist.get(i);
				tuple.prob /= s1;
				paProb += tuple.prob;
				tuple.aProb = paProb;
			}
			if(i<nlist.size()){
				tuple = nlist.get(i);
				tuple.prob /= s2;
				naProb += tuple.prob;
				tuple.aProb = naProb;
			}
		}
//		System.out.println(paProb+" "+naProb);
	}
	public double calcErrRate(){
		int count=0;
		Tuple tuple;
		int size = plist.size()>nlist.size()?plist.size():nlist.size();
		
		for(int i=0;i<size;i++){
			if(i<plist.size()){
				tuple = plist.get(i);
				if(tuple.isErr)count++;
			}
			if(i<nlist.size()){
				tuple = nlist.get(i);
				if(tuple.isErr)count++;
			}
		}
		return count*1.0/(plist.size()+nlist.size());
	}
	/**
	 * serialized in plist and nlist
	 * */
	public void read(){
		File fp = new File("sampling/psampling.out");
		File fn = new File("sampling/nsampling.out");
		if(!fn.exists()){
			initialize();
		}
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream(fp));
			plist = (ArrayList<Tuple>)ModelIn.readObject();
			ModelIn.close();
			ModelIn=new ObjectInputStream(
						new FileInputStream(fn));
			nlist = (ArrayList<Tuple>)ModelIn.readObject();
			ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * initialize plist and nlist
	 * */
	private void initialize(){
		String line;
		int k = 0;
		RandomAccessFile raf;
		String[] str;
		String rid,stars;
		double pProb, nProb, naProb=0, paProb=0;
		int irid;
		int pcount=0,ncount=0;
		CStar star;
		System.out.println("-- start initialization --");
		
		try {
			raf = new RandomAccessFile(tpfile,"r");
			while((line=raf.readLine())!=null){
				line = line.trim();
				if(line.isEmpty()) continue;
				str=line.split("\t");
				rid=str[0];
				stars=str[2];
				irid = Integer.parseInt(rid);
				star = getStar(stars);
				if(star==CStar.ONE||star==CStar.TWO){
					ncount++;
				}else if(star==CStar.FOU||star==CStar.FIV){  
					pcount++;
				}
			}
			pProb = 1.0/pcount;
			nProb = 1.0/ncount;
			System.out.println("pcount:"+pcount+" ncount:"+ncount+" pProb:"+pProb+" nProb:"+nProb);
				
			raf = new RandomAccessFile(tpfile,"r");
			while((line=raf.readLine())!=null){
				line = line.trim();
				if(line.isEmpty()) continue;
				str=line.split("\t");
				rid=str[0];
				stars=str[2];
				irid = Integer.parseInt(rid);
				star = getStar(stars);
				if(star==CStar.ONE||star==CStar.TWO){
					naProb += nProb;
					nlist.add(new Tuple(irid,nProb,naProb));
				}else if(star==CStar.FOU||star==CStar.FIV){	
					paProb += pProb;
					plist.add(new Tuple(irid,pProb,paProb));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		/* serialization */
		try{
			ObjectOutputStream ModelOut=
				new ObjectOutputStream(
					new FileOutputStream("sampling/psampling.out"));
			ModelOut.writeObject(plist);
			ModelOut.close();
			
			ModelOut=new ObjectOutputStream(
						new FileOutputStream("sampling/nsampling.out"));
				ModelOut.writeObject(nlist);
				ModelOut.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	private CStar getStar(String star){
		int k;
		try{
			k = Integer.parseInt(star.trim());
			switch (k){
			case 1: return CStar.ONE;
			case 2:	return CStar.TWO;
			case 3:	return CStar.THR;
			case 4:	return CStar.FOU;
			case 5:	return CStar.FIV;
			}
		}catch(Exception e){
			return null;
		}
		return null;
	}
	private int count(){
		Set<Entry<Integer, Integer>> set = tCount.hmap.entrySet();
		Iterator<Entry<Integer, Integer>> it = set.iterator();
		Entry<Integer, Integer> entry;
		int sum = 0;
		while(it.hasNext()){
			entry = it.next();
			sum += entry.getValue();
		}
		return sum;
	}

	public static void main(String[] args){
		String tfile="";
		if(args[1].equals("mu")){
			tfile=GlobalVars.getInstance().trainMuFile;
		}else if(args[1].equals("lamda")){
			tfile=GlobalVars.getInstance().trainFile;
		}else{
			System.err.println("Error parameter!");
			return;
		}
		Resample rs = new Resample(tfile);
		if(args[0].equals("first")){
			System.out.println("-- first time for runing sampling --");
			rs.run(true);
		}else{
			rs.run(false);
		}
		
	}
	private void test(){
		ArrayList<Tuple> list = new ArrayList<Tuple>();
		list.add(new Tuple(1, 0.1, 0.1));
		list.add(new Tuple(2, 0.1, 0.2));
		list.add(new Tuple(3, 0.1, 0.3));
		list.add(new Tuple(4, 0.1, 0.4));
		list.add(new Tuple(5, 0.1, 0.5));
		list.add(new Tuple(6, 0.1, 0.6));
		list.add(new Tuple(7, 0.1, 0.7));
		list.add(new Tuple(8, 0.1, 0.8));
		list.add(new Tuple(9, 0.1, 0.9));
		list.add(new Tuple(10, 0.1, 1));
		int index ;
		double val;
		
		for(int i=0;i<20;i++){
			val = Math.random();
			index = hit(list, val);
			System.out.println(val+":"+list.get(index).rid);
		}
	}
	private void test2(){
		int size = tCount.hmap.size();
		System.out.println(size);
		Set<Entry<Integer, Integer>> set = tCount.hmap.entrySet();
		Iterator<Entry<Integer, Integer>> it = set.iterator();
		Entry<Integer, Integer> entry;
		int sum = 0;
		while(it.hasNext()){
			entry = it.next();
			sum += entry.getValue();
		}
		System.out.println(sum);
	}
	private void test3(){
		plist.add(new Tuple(1, 0.1, 0.1));
		plist.add(new Tuple(2, 0.1, 0.2));
		plist.add(new Tuple(3, 0.1, 0.3));
		plist.add(new Tuple(4, 0.1, 0.4));
		plist.add(new Tuple(5, 0.1, 0.5));
		plist.add(new Tuple(6, 0.1, 0.6));
		plist.add(new Tuple(7, 0.1, 0.7));
		plist.add(new Tuple(8, 0.1, 0.8));
		plist.add(new Tuple(9, 0.1, 0.9));
		plist.add(new Tuple(10, 0.1, 1));
		nlist.add(new Tuple(11, 0.2, 0.2));
		nlist.add(new Tuple(12, 0.6, 0.8));
		nlist.add(new Tuple(13, 0.1, 1));
		
		sampling();
		int size = tCount.size();
		System.out.println(size);
		Set<Entry<Integer, Integer>> set = tCount.hmap.entrySet();
		Iterator<Entry<Integer, Integer>> it = set.iterator();
		Entry<Integer, Integer> entry;
		int sum = 0;
		while(it.hasNext()){
			entry = it.next();
			sum += entry.getValue();
			System.out.println(entry.getKey()+":"+entry.getValue());
		}
		System.out.println(sum);
	}
}


