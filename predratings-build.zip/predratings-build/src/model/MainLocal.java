package model;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
/**
 * train a global model
 * @deprecated
 * */

public class MainLocal {
	
	public static void main(String[] args) {
		MainLocal generator = new MainLocal();
		try {
			generator.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void run() throws Exception{
		System.out.println("-- TrainLocalModel --");
		TrainLocalModel gtrain = new TrainLocalModel();
		gtrain.run();
		
		/* serialization */
		try{
			ObjectOutputStream ModelOut=
				new ObjectOutputStream(
					new FileOutputStream("business/b1.out"));
			ModelOut.writeObject(gtrain.lamda);
			ModelOut.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
}
