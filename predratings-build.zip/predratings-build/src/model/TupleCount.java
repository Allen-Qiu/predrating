package model;

import java.util.HashMap;

/**
 * give the count of a tuple (record) should be sampled.
 * TrainCRFModel8.java uses it.
 * */
public class TupleCount implements java.io.Serializable{
	HashMap<Integer, Integer> hmap;
	
	public TupleCount(){
		hmap = new HashMap<Integer, Integer>();
	}
	public int size(){
		return hmap.size();
	}
	public void put(int index, int count){
		hmap.put(index,count);
	}
	/**
	 * if index does not exist, the function return null.
	 * */
	public Integer get(int index){
		return hmap.get(index);
	}
}
