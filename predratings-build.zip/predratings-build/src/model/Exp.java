package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;

import model.CStar;
import model.Comment;

/**
 * Polarity: only use lamda learned from SentiCRF to make a prediction.
 * use this program after TrainCRFModel8.
 * update plist and nlist (psampling.out and nsampling.out) 
 * */
public class Exp {
	ArrayList<Tuple> plist,nlist;
	HashMap<Integer,Integer> pmap, nmap;
	final int POS=0, NEG=1;
	
	public static void main(String[] args) {
		System.out.println("-- expriment --");
		Exp exp = new Exp();
		exp.run();
	}
	/**
	 * testing polarity
	 * */
	private void run(){
		String line,stars,review;
		String[] str;
		RandomAccessFile raf;
		Comment comment;
		int k1=0,num1=0,err=0;
		int k2=0,num2=0;
		LamdaModel lmodel = new LamdaModel();
		int polar;
		CStar cs;
		int rid;
		
		read();
		buildMap();
		try {
			raf = new RandomAccessFile(GlobalVars.getInstance().trainFile,"r");
			while((line=raf.readLine())!=null){
				line=line.trim();
				if(line.isEmpty()) continue;
				str=line.split("\t");
				review=str[1];
				stars=str[2];
				rid = Integer.parseInt(str[0]);
				comment = new Comment(rid,stars,review);
				if(comment.getCStar()==CStar.THR) continue;
				polar=lmodel.predict(comment);
				if(polar==-1){
					err++;
					continue;
				}
				cs=comment.getCStar();
				if(map(cs)==POS){
					if(map(cs)==polar){	// correct classification for pos tuple
						k1++;
						updateErrPTuple(rid,false);
					}else{
						updateErrPTuple(rid,true);
					}
					num1++;
				}else{
					if(map(cs)==polar){ // correct classfication for neg tuple
						k2++;
						updateErrNTuple(rid, false);
					}else{
						updateErrNTuple(rid, true);
					}
					num2++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		/* serialization */
		String ps="sampling/psampling.out";
		String ns="sampling/nsampling.out";
//		File pf = new File(ps);
//		File nf = new File(ns);
//		pf.delete();
//		nf.delete();
		
		try{
			ObjectOutputStream ModelOut=
				new ObjectOutputStream(
					new FileOutputStream(ps));
			ModelOut.writeObject(plist);
			ModelOut.close();
			
			ModelOut=new ObjectOutputStream(
					new FileOutputStream(ns));
			ModelOut.writeObject(nlist);
			ModelOut.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		System.out.println(num1+" "+k1+" "+k1*1.0/num1);
		System.out.println(num2+" "+k2+" "+k2*1.0/num2);
		System.out.println((num1+num2)+" "+(k1+k2)+" "+(k1+k2)*1.0/(num1+num2));
		System.out.println(err);
		
	}	
	private int map(CStar cstar){
		if(cstar==CStar.FIV||cstar==CStar.FOU) return POS;
		if(cstar==CStar.ONE||cstar==CStar.TWO) return NEG;
		return -1;
	}
	private void read(){
		File fp = new File("sampling/psampling.out");
		File fn = new File("sampling/nsampling.out");
		
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream(fp));
			plist = (ArrayList<Tuple>)ModelIn.readObject();
			ModelIn.close();
			ModelIn=
					new ObjectInputStream(
						new FileInputStream(fn));
				nlist = (ArrayList<Tuple>)ModelIn.readObject();
				ModelIn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	private void buildMap(){
		Tuple tuple;
		pmap=new HashMap<Integer,Integer>() ;
		nmap=new HashMap<Integer,Integer>() ;
		for(int i=0;i<plist.size();i++){
			tuple = plist.get(i);
			pmap.put(tuple.rid, i);
		}
		for(int i=0;i<nlist.size();i++){
			tuple = nlist.get(i);
			nmap.put(tuple.rid, i);
		}
	}
	/**
	 * update misclassification positive tuple
	 * */
	private void updateErrPTuple(int rid,boolean r){
		int index = pmap.get(rid);
		Tuple tuple = plist.get(index);
		tuple.isErr = r;
	}
	/**
	 * update misclassification negative tuple
	 * */
	private void updateErrNTuple(int rid, boolean r){
		int index = nmap.get(rid);
		Tuple tuple = nlist.get(index);
		tuple.isErr = r;
	}
}
