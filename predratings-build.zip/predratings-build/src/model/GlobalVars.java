package model;

import java.io.FileInputStream;
import java.util.Properties;

import dataset.OperateDB;
import qjt.predratings.PathVar;

public class GlobalVars {
	public String dbName;	
	public String stoplist;
	public String trainFile;
	public String trainMuFile;
	public String dicName;
	public String invDicName;
	public String isEng;
	
	private static final GlobalVars Instance=new GlobalVars();
	private GlobalVars(){
		read();
	}
	public static GlobalVars getInstance(){
		return Instance;
	}
	private void read(){
		Properties prop = new Properties();
        try {
			prop.load(new FileInputStream(PathVar.path+"GlobalVars.properties"));
			dbName = prop.getProperty("dbName"); 
			stoplist = prop.getProperty("stoplist");
			trainFile = prop.getProperty("trainFile");
			trainMuFile = prop.getProperty("trainMuFile");
			dicName = prop.getProperty("dicname");
			invDicName=prop.getProperty("invdicname");
			isEng=prop.getProperty("isEng");
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	public static void main(String args[]){
		System.out.println(GlobalVars.getInstance().trainFile);
		System.out.println(GlobalVars.getInstance().dbName);
		System.out.println(GlobalVars.getInstance().stoplist);
		System.out.println(GlobalVars.getInstance().dicName);
		System.out.println(GlobalVars.getInstance().invDicName);
	}
}
