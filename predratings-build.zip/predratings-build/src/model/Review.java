package model;

import java.util.Vector;


/**
 * ѵ��mu modelʱʹ��
 * */
public class Review{
	private int rid;
	Vector<Integer> terms;
	CStar cstar;
	public Review(int rid, String cstar, String[] terms){
		this.rid=rid;
		this.cstar=getStar(cstar);
		this.terms=convert(terms);
	}
	public int getRid(){
		return rid;
	}
	public CStar getCStar(){
		return cstar;
	}
	public Vector<Integer> getTerms(){
		return terms;
	}
	private Vector<Integer> convert(String[] terms){
		Vector<Integer> vec = new Vector<Integer>();
		int val;
		String term;
		for(int i=0;i<terms.length;i++){
			term=terms[i].trim();
			if(term.isEmpty()) continue;
			val = Integer.parseInt(term);
			vec.addElement(val);
		}
		return vec;
	}
	private CStar getStar(String star){
		int k;
		try{
			k = Integer.parseInt(star.trim());
			switch (k){
			case 1: return CStar.ONE;
			case 2:	return CStar.TWO;
			case 3:	return CStar.THR;
			case 4:	return CStar.FOU;
			case 5:	return CStar.FIV;
			}
		}catch(Exception e){
			return null;
		}
		return null;
	}
}

